# -*- coding: utf-8 -*-
"""Rewrite the CHINESE manuscript Introduction + Discussion to fully correspond
to the rewritten ENGLISH version, using the SAME 27 references in the SAME order."""
import re, shutil

MD = "SCI_Manuscript_CN_2026-10-13.md"

# fixed numbering = the English first-appearance order
ORDER = ["duller2024","kumpitsch2021","villanueva2022","mohammadzadeh2026","li2025","wang2022",
"woh2025","pimentel2026","rezaie2016","takahashi2014","parada2015","gloor2017","mcmurdie2014",
"weiss2017","vandeputte2017","bokulich2013","orgler2024","mirza2022","fumagalli2025","zhao2025",
"yamamura2025","gallardo2026","hu2024","chen2025","talamantes2024","laserna2024","wang2025b"]
NUM = {k:i+1 for i,k in enumerate(ORDER)}

ENTRIES = {
 "duller2024":"Duller et al. Targeted isolation of Methanobrevibacter strains from fecal samples expands the cultivated human archaeome. Nature Communications. 2024. doi:10.1038/s41467-024-52037-7",
 "kumpitsch2021":"Kumpitsch et al. Reduced B12 uptake and increased gastrointestinal formate are associated with archaeome-mediated breath methane emission in humans. Microbiome. 2021. doi:10.1186/s40168-021-01130-w",
 "mohammadzadeh2026":"Mohammadzadeh et al. Cross-domain metabolic interactions link Methanobrevibacter smithii to colorectal cancer microbial ecosystems. Nature Communications. 2026. doi:10.1038/s41467-026-69711-7",
 "li2025":"Li et al. Multi-Cohort Analysis Reveals Altered Archaea in Colorectal Cancer Fecal Samples Across Populations. Gastroenterology. 2025. doi:10.1053/j.gastro.2024.10.023",
 "wang2022":"Wang et al. Methanogen Levels Are Significantly Associated with Fecal Microbiota Composition and Alpha Diversity in Healthy Adults and Irritable Bowel Syndrome Patients. Microbiology Spectrum. 2022. doi:10.1128/spectrum.01653-22",
 "orgler2024":"Orgler et al. Archaea influence composition of endoscopically visible ileocolonic biofilms. Gut Microbes. 2024. doi:10.1080/19490976.2024.2359500",
 "woh2025":"Woh et al. Reevaluation of the gastrointestinal methanogenic archaeome in multiple sclerosis and its association with treatment. Microbiology Spectrum. 2025. doi:10.1128/spectrum.02183-24",
 "villanueva2022":"Villanueva-Millan et al. Methanogens and Hydrogen Sulfide Producing Bacteria Guide Distinct Gut Microbe Profiles and Irritable Bowel Syndrome Subtypes. American Journal of Gastroenterology. 2022. doi:10.14309/ajg.0000000000001997",
 "pimentel2026":"Pimentel et al. Real-world Study of Three-gas Breath Testing Nationwide and the Association With Symptoms. Journal of Clinical Gastroenterology. 2026. doi:10.1097/MCG.0000000000002326",
 "rezaie2016":"Rezaie et al. How to Test and Treat Small Intestinal Bacterial Overgrowth: an Evidence-Based Approach. Current Gastroenterology Reports. 2016. doi:10.1007/s11894-015-0482-9",
 "gallardo2026":"Gallardo-Nuell et al. Ecological restructuring of the nonbacterial fecal microbiome in obesity across human cohorts. Gut Microbes. 2026. doi:10.1080/19490976.2026.2701446",
 "mirza2022":"Mirza et al. Metagenomic Analysis of the Pediatric-Onset Multiple Sclerosis Gut Microbiome. Neurology. 2022. doi:10.1212/WNL.0000000000013245",
 "fumagalli2025":"Fumagalli et al. Archaea methanogens are associated with cognitive performance through the shaping of gut microbiota, butyrate and histidine metabolism. Gut Microbes. 2025. doi:10.1080/19490976.2025.2455506",
 "zhao2025":"Zhao et al. The gut methanotroph Methylocystis intestini modulates intestinal peristalsis and fat metabolism via reducing methane levels. Nature Communications. 2025. doi:10.1038/s41467-025-66596-w",
 "talamantes2024":"Talamantes et al. Intestinal Methanogen Overgrowth (IMO) Is Associated with Delayed Small Bowel and Colonic Transit Time (TT) on the Wireless Motility Capsule (WMC). Digestive Diseases and Sciences. 2024. doi:10.1007/s10620-024-08563-x",
 "chen2025":"Chen et al. Multi-kingdom gut microbiota dysbiosis is associated with the development of pulmonary arterial hypertension. eBioMedicine. 2025. doi:10.1016/j.ebiom.2025.105686",
 "yamamura2025":"Yamamura et al. Increased fecal glycocholic acid levels correlate with obesity in conjunction with the depletion of archaea: The Dosanco Health Study. The Journal of Nutritional Biochemistry. 2025. doi:10.1016/j.jnutbio.2025.109846",
 "wang2025b":"Wang et al. Intestinal methanogen overgrowth and its impact on gastrointestinal disorders in children: a retrospective study. BMC Gastroenterology. 2025. doi:10.1186/s12876-025-04406-9",
 "laserna2024":"Laserna Mendieta et al. Detection capacity of small intestine bacterial or methanogen overgrowth by lactose and fructose breath testing in the adult population. Advances in Laboratory Medicine. 2024. doi:10.1515/almed-2024-0115",
 "hu2024":"Hu et al. Integrative metagenomic analysis reveals distinct gut microbial signatures related to obesity. BMC Microbiology. 2024. doi:10.1186/s12866-024-03278-5",
 "gloor2017":"Gloor et al. Microbiome datasets are compositional: and this is not optional. Frontiers in Microbiology. 2017. doi:10.3389/fmicb.2017.02224",
 "vandeputte2017":"Vandeputte et al. Quantitative microbiome profiling links gut community variation to microbial load. Nature. 2017. doi:10.1038/nature24460",
 "bokulich2013":"Bokulich et al. Quality-filtering vastly improves diversity estimates from Illumina amplicon sequencing. Nature Methods. 2013. doi:10.1038/nmeth.2276",
 "mcmurdie2014":"McMurdie et al. Waste not, want not: why rarefying microbiome data is inadmissible. PLoS Computational Biology. 2014. doi:10.1371/journal.pcbi.1003531",
 "weiss2017":"Weiss et al. Normalization and microbial differential abundance strategies depend upon data characteristics. Microbiome. 2017. doi:10.1186/s40168-017-0237-y",
 "parada2015":"Parada et al. Every base matters: assessing small subunit rRNA primers for marine microbiomes with mock communities, time series and global field samples. Environmental Microbiology. 2015. doi:10.1111/1462-2920.13023",
 "takahashi2014":"Takahashi et al. Development of a prokaryotic universal primer for simultaneous analysis of Bacteria and Archaea using next-generation sequencing. PLoS ONE. 2014. doi:10.1371/journal.pone.0105592",
}

NEW_INTRO = r"""## 1 引言

产甲烷古菌（以 *Methanobrevibacter smithii* 为主 {duller2024}）催化结肠发酵的末端步骤，将 H₂/CO₂、甲酸盐或甲基化底物还原为甲烷，从而降低原本限制发酵中 NADH 再氧化的氢分压（pH₂）{kumpitsch2021}。由于这一氢汇与乙酸、丙酸、丁酸、甲酸盐及胆汁酸的互变相耦合，产甲烷菌处于一个连接微生物能量学、宿主能量获取与黏膜氧化还原状态的代谢枢纽 {kumpitsch2021,villanueva2022}。所报告的疾病关联呈方向性分化：古菌丰度在结直肠癌（CRC）中倾向升高 {mohammadzadeh2026,li2025,wang2022}，在炎症性肠病（IBD）中倾向降低 {wang2022,woh2025}。CRC 侧的升高与肿瘤微环境中氢/硫代谢的重排相容；IBD 侧的降低则与硫酸盐还原的竞争、以及伴随炎症的黏膜氧与硝酸盐升高相容；两种表型亦呈现产甲烷菌与产硫化氢菌相反的临床表现 {villanueva2022}。

临床上，产甲烷菌载量并非被动协变量：甲烷作为诊断与治疗靶点，经呼气检测与"肠道产甲烷菌过度生长（IMO）"框架被加以利用 {pimentel2026,rezaie2016}。然而这一临床信号所依赖的测量处于差异极大的分辨率层次——呼气气体、靶向定量 PCR、非靶向鸟枪法测序——三者之间的一致性鲜有被量化。

一个基本未被审视的前提是：公开微生物组数据使所有微生物类群"无偏可见"。实际上，主流分类器与扩增子引物体系均围绕细菌参考序列与细菌 16S rRNA 基因覆盖度优化，其对低丰度、引物错配古菌的灵敏度从未被系统基准化 {takahashi2014,parada2015}。后果有两个方向：其一，阴性结果可能反映检出失效而非生物学缺失；其二，由于相对丰度估计是组成性的 {gloor2017} 且依赖一个隐含的检出下限，跨人群与跨平台的可检出性差异会以难以察觉的方式混淆关联与因果推断——同一生物学信号可能在某数据集可测、在另一数据集不可见。这些问题被常规分析选择进一步放大：计数归一化与稀释化会同时改变下游检验的灵敏度与特异度 {mcmurdie2014,weiss2017}，而相对丰度谱对归一化所丢弃的微生物载量敏感 {vandeputte2017}。

低丰度类群总体上处于鸟枪法与扩增子数据的检出边缘，故"未检出"常被径直写作"不存在" {weiss2017,vandeputte2017}。肠道古菌是这一问题格外有信息量的探针：其丰度低、其 16S rRNA 基因与细菌型引物匹配差 {takahashi2014,parada2015}，且其疾病关联既被报为阳性也被报为阴性——这正是弱生物学信号在检出限附近被测量时预期的异质性。

本研究以产甲烷古菌—CRC/IBD 关联为案例，检验一个含三部分的命题：公开粪便宏基因组与扩增子数据对肠道古菌存在系统性检出失效；该失效随测序深度、引物化学与人群呈可量化梯度；并以可由"类群被检出程度"预测的方向扭曲下游统计推断。产甲烷菌—疾病关联在此既是研究对象，也是暴露该检出失效的诊断性探针。

**继承与增量。** 本文继承自"慢性低氧下瘤胃产甲烷"研究中的一项概念立场：产甲烷菌是末端氢汇，其表观丰度是环境与测量方式的联合属性——"存在多少产甲烷能力"与"能看到多少"并非同一个问题。以氢分压为核心、把产甲烷与发酵末端产物及黏膜氧化还原状态相耦合、并借"天然极端系统"暴露常规条件下被掩盖的约束——这一思路在此被移用于另一个系统：以公开测序数据观察的人体结肠。本文的增量是定量与方法学而非概念上的：我们不提出新的古菌—疾病机制，而是对现有人体宏基因组做一次受检出限制的再评估，形式化出最低可检出丰度、随深度变化的检出梯度，以及可反转关联符号的"检出—丰度"分解。"""

NEW_DISC = r"""## 4 讨论

### 4.1 主要发现
三条独立证据线汇聚为一个结论：公开粪便数据中可报告的古菌信号是一个深度与流程依赖量，而非固定的生物学属性；常规报告的疾病关联受"类群被检出程度"塑造。(i) 在一个真实、组成已知的 mock 群落中，管线准确且特异（假阳 0%、回收≈100%），故限制来自采样而非比对。(ii) 在 26,731 份公开粪便宏基因组中，检出几率每增加一个 log10 读数上升 2.07 倍（p=1.3×10⁻¹⁸）；该关系显著非线性且下凹，留一研究重拟合稳定（0.654–0.874），且未检出疾病分组关联。(iii) 对真实 mock 的再分析确立最低可检出丰度（MDA）约为期望 3 条读数（25,000 读数时≈0.012%；1,000,000 时≈0.0003%），该阈值按 ~3/深度 缩放。三者合起来，把"古菌可能被低估检出"这一质性忧虑，转化为一个可在解读关联之前施加于数据集的定量判据。

### 4.2 检出—丰度框架
必须区分三个常被混淆的量：**检出率**是样本集合的患病率式属性；**测定灵敏度**是在给定丰度与深度下检出存在类群的概率；**充分性**是数据集对某类群是否有信息量。由于 MDA 按 ~3/深度 缩放，充分性是丰度与深度的联合属性而非研究标签的属性，故同一数据集可对 1% 丰度的生物充分、却同时对 0.01% 的古菌失明。将这一分解用于 15 个病例—对照研究的 281 个属，显示数个最常报告的 IBD"耗竭"——包括 *Akkermansia*——由检出率丧失承载（患病率 OR 0.16–0.43；4 个研究中 3 个 p<0.01），而非阳性样本内丰度下降（全尺度 g −0.42 vs 阳性内 −0.03）。**两部分（检出＋条件丰度）模型**是此处的自然估计量，因为单张零膨胀的相对丰度表本身无法区分生物学零与采样零 {mcmurdie2014,weiss2017}。同一警示亦适用于质量过滤与归一化所设定的有效检出阈值 {bokulich2013}，以及限制相对丰度数据作为群落代理的组成性约束 {gloor2017}。

### 4.3 与既往工作的关系
既往古菌研究已提示产甲烷菌追踪宿主代谢与疾病 {mohammadzadeh2026,li2025,wang2022,woh2025}、呼气甲烷反映古菌载量 {pimentel2026,rezaie2016}、古菌塑造生物膜与系统表型 {orgler2024,mirza2022,fumagalli2025,zhao2025}，且古菌丰度与肥胖、胆汁酸及多界表型共变 {yamamura2025,gallardo2026,hu2024,chen2025}。本文的贡献不是新关联，而是对这些信号**如何变得可见**的一次技术审计：同一批读数数据，因深度、引物与平台不同，可支持相反结论。这用一个统一的采样机制调和了古菌文献长期存在的异质性——某些队列近乎无效、另一些强效——并推广到任何处于检出边缘的类群。

本审计所用的方法学要素本身早已确立。引物选择强力决定哪些类群可被回收，因为古菌 16S rRNA 基因与细菌型引物匹配差 {takahashi2014,parada2015}。计数归一化与稀释化会改变下游检验的灵敏度与特异度 {mcmurdie2014,weiss2017}，质量过滤对稀有序列设定有效阈值 {bokulich2013}，相对丰度谱是组成性的、不携带绝对载量信息 {gloor2017}，而绝对定量会改变对同一群落的生物学解读 {vandeputte2017}。所缺的不是工具箱，而是将其系统地应用于一个具体且临床相关的关联，并给出一个明确的检出阈值，使数据集在关联被解读之前即可被评判。

另一支既往工作——慢性低氧下的瘤胃发酵——早已把产甲烷**重新定义为一次氧化还原事件**：低氧发酵器中的甲烷输出是一条氢经济的末端步骤，其上限受可用氧化剂约束，故可观测的甲烷信号既取决于产甲烷菌群落，也同等取决于**还原性环境**本身 {kumpitsch2021}。本文把这一"重新定向"从一个**深测序为常态**的系统，移到一个**公开数据通常较浅**的系统，并提出对称的问题：若环境限定了产甲烷菌能*做*什么，那么测序深度又在多大程度上限定了我们能*看见*什么？得到的答案——**MDA≈3 条读数**与随深度变化的检出梯度——正是该氧化还原框架在人肠侧的对应物，也正是它使所报告的疾病关联成为一个**方法学**（而非纯生物学）不确定性的对象。

### 4.4 替代解释与可证伪预测
除检出失效外，至少还有四种解释可产生弱或不一致的产甲烷菌—疾病关联，而它们给出不同预测。(i) **真实但微小的生物学效应**预测：深度调整应使效应量不变——这正是我们在分组对比中所观察到的（CRC +0.407→+0.408；IBD −0.408→−0.394）。(ii) **组成性位移**（古菌比例变化仅因其他类群变化）预测：功能性产甲烷能力不应随分类学比例移动——然而 METHANOGENESIS-PWY 在 CRC 上升 3.80 倍、在 IBD 降至 0.34 倍 {gloor2017}。(iii) **被归一化移除的绝对微生物载量差异** {vandeputte2017} 预测：载量校正模型会消除信号；校正总载量后估计变化至多 1.8%。(iv) **研究或平台层级的技术偏倚**预测：效应应在同一样本内随深度漂移——深度衰减实验证实了这一点（中国队列：深度由 2.5×10⁴ 升至 5×10⁵ 读数时，检出 31%→73%、g +0.190→+0.315）。故该模式与"真实但受检出限制的关联"最为相容。能判定此问题的**区分性测量**在此被明确为证伪检验：在同批样本的深测与浅测等分上，以 spike-in 标准用定量 PCR 测绝对古菌载量——若检出失效假说成立，应能重现深度依赖信号；若不成立，则不能。

### 4.5 机制解释
关联的方向与"肠道氢经济"读法相容。在 CRC 中，肿瘤微环境中黏液与硫代谢的改变可提高氢的可利用性并减少竞争性硫酸盐还原，从而有利于产甲烷菌；在 IBD 中，炎症升高黏膜氧与硝酸盐，既不利于严格厌氧的产甲烷菌，也有利于硝酸盐与硫呼吸的竞争者 {villanueva2022}。在这一读法下，相关的状态变量是**氢分压与肠腔氧化还原电位**，而非丰度本身——而经相对丰度透镜测量的一个类群，是气相过程的劣质代理。甲烷池并非惰性，已有证据显示肠道甲烷氧化菌可降低甲烷并改变蠕动与脂肪代谢 {zhao2025}；同理，一个受检出限制的分类学信号不能替代通量测量。

### 4.6 对实践与临床转化的意义
四项报告规范直接来自结果。(i) 分别报告分析深度与有效（QC 后）深度。(ii) 明示判阳规则及其阈值敏感性——在本研究中，同一深度下检出从 ≥1 读数的 41% 降至 ≥5 读数的 15%。(iii) 对低患病率类群，用两部分模型分别报告检出与丰度。(iv) 报告针对数据推导 MDA 的"丰度×深度"充分性检查。这些步骤廉价、可复现，能把"无证据"转化为"关于缺失的证据"。就临床转化而言，同一推理适用于呼气检测与 IMO：呼气甲烷与基于测序的丰度处于不同深度、具有不同检出下限 {pimentel2026,rezaie2016,talamantes2024,laserna2024}，故一次阴性呼气试验与浅测宏基因组中未检出的古菌，可能反映同一采样限制而非真实缺失 {wang2025b}。把检出与丰度分开报告、并写明深度与判阳规则，将使研究与临床信号在不同平台间可比。

### 4.7 局限
真值 mock 含的是嗜盐古菌而非肠道产甲烷菌，且 MDA 掺入为叠于**真实细菌背景上的模拟读数**——故 MDA 为灵敏度**上限**而非粪便基质真值，且对真实 DNA（受提取、PCR 与建库偏倚影响）会偏乐观地小。定量线**无法分离地区与研究层级技术效应**，故所有地区结论均为探索性。MR **功效不足**（观测效应下≈0.23），不能验证检出机制。未测绝对载量，故不能正式排除**组成性影响**。最后，原始读长复现与定量线**重叠**，属跨流程一致性而非外部验证。

### 4.8 结论与展望
**"未检出"不等于"不存在"。** 受深度限制的检出系统性决定了哪些肠道古菌（及其他低丰度类群）可见，并可能**反转**所报告的微生物组—疾病关联的符号。量化**最低可检出丰度**、并把**检出与丰度分开报告**，将使下一代的微生物组关联**可复现**，而非取决于样本"碰巧被测了多深、用了什么引物"。

四个问题仍未解决，在此作为显式缺口列出。其一，跨人群的肠道古菌真实绝对丰度是多少，且在以定量 PCR 配合标准、对深测材料测量后，它是否仍追踪所报告的疾病关联？其二，此处观察到的深度依赖检出梯度是否对其他引物体系（含古菌兼容的 16S 测定与长读长平台）成立？其三，所报告的产甲烷菌—疾病关联在多大测序深度下才跨队列稳定，且该深度在人群尺度上是否可达？其四，能否把数据推导的 MDA 与前瞻性功效计算相耦合，从而在检验关联之前（而非事后）就规定数据集充分性？"""

def main():
    s = open(MD, encoding="utf-8").read()
    shutil.copyfile(MD, MD + ".bak5")

    a = s.index("## 1 引言"); b = s.index("## 2 材料与方法")
    s = s[:a] + NEW_INTRO + "\n\n---\n\n" + s[b:]

    a = s.index("## 4 讨论"); b = s.index("## 参考文献")
    s = s[:a] + NEW_DISC + "\n\n" + s[b:]

    def repl(m):
        keys = [k.strip() for k in m.group(1).split(',') if k.strip()]
        nums = sorted(set(NUM[k] for k in keys if k in NUM))
        out, i = [], 0
        while i < len(nums):
            j = i
            while j+1 < len(nums) and nums[j+1] == nums[j]+1: j += 1
            if j-i >= 2: out.append("%d-%d" % (nums[i], nums[j]))
            else: out.extend(str(x) for x in nums[i:j+1])
            i = j+1
        return "[" + ",".join(out) + "]"
    s = re.sub(r"\{([^}]+)\}", repl, s)

    reflines = ["%d. %s" % (i+1, ENTRIES[k]) for i, k in enumerate(ORDER)]
    ra = s.index("## 参考文献"); rb = s.index("## 5 后置章节")
    s = s[:ra] + "## 参考文献\n\n" + "\n".join(reflines) + "\n\n" + s[rb:]
    s = s.replace("\n> 参考文献将自核验库按**首次引用顺序**插入；摘要、结果、结论**零引用**。", "")

    open(MD, "w", encoding="utf-8").write(s)

    ab = s[s.index("## 摘要"):s.index("## 1 引言")]
    res = s[s.index("## 3 结果"):s.index("## 4 讨论")]
    print("cite in 摘要:", bool(re.search(r"\[\d", ab)))
    print("cite in 结果:", bool(re.search(r"\[\d", res)))
    seen=[]
    for m in re.finditer(r"\[([0-9,\-]+)\]", s[:s.index("## 参考文献")]):
        for p in m.group(1).split(','):
            rng = range(int(p.split('-')[0]), int(p.split('-')[1])+1) if '-' in p else [int(p)]
            for n in rng:
                if n not in seen: seen.append(n)
    print("CN 首现序列:", seen)
    print("严格升序:", seen == list(range(1,28)))

main()
