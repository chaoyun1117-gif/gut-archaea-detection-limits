#!/bin/bash
cd /home/admin/arch_db
OUT=/home/admin/arch_db/16s_full_results.tsv
export OUT
echo -e "grp\trun\tproj\ttot\tarch\tmeth\tarc_tot\tarcfrac\tstatus" > "$OUT"
cat all16s_input.tsv | xargs -P 4 -n 4 /home/admin/arch_db/work16s.sh
echo "ALL_DONE $(wc -l < "$OUT") $(date)" > /home/admin/arch_db/16s_DONE.txt
