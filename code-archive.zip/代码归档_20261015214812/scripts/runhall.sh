#!/bin/bash
cd /home/admin/arch_db
export OUT=/home/admin/arch_db/hall_results.tsv
echo -e "grp\trun\ttot\tarch\tstatus" > "$OUT"
cat hall_input.tsv | xargs -P 4 -n 3 /home/admin/arch_db/workhall.sh
echo "HALL_DONE $(wc -l < "$OUT") $(date)" > /home/admin/arch_db/hall_DONE.txt
