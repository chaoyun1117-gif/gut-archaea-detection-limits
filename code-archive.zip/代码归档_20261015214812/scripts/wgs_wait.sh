#!/bin/bash
cd /home/admin/arch_db
for i in $(seq 1 180); do [ -f mbarc/DL_DONE.txt ] && break; sleep 20; done
sleep 3
echo "DL done: $(cat mbarc/DL_DONE.txt 2>/dev/null)"
for f in mbarc/wgs_*.fq; do echo "$f: $(($(wc -l < $f)/4)) reads"; done
