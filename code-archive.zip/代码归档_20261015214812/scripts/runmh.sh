#!/bin/bash
cd /home/admin/arch_db
OUT=/home/admin/arch_db/metahit_results.tsv
export OUT
echo -e "cond\trun\tsubj\ttot\tarch\tstatus" > "$OUT"
cat metahit_input.tsv | xargs -P 4 -n 4 /home/admin/arch_db/workmh.sh
echo "META_DONE $(wc -l < "$OUT") $(date)" > /home/admin/arch_db/metahit_DONE.txt
