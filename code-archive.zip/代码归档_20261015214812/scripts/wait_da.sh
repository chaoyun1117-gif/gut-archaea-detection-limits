#!/bin/bash
cd /home/admin/arch_db
for i in $(seq 1 200); do [ -f da_DONE.txt ] && break; sleep 30; done
sleep 10
echo "=== DONE ==="; cat da_DONE.txt 2>/dev/null
python3 /home/admin/arch_db/analyze_da.py 2>&1 | tee /home/admin/arch_db/da_analysis.txt
echo "==DA_COMPLETE=="
