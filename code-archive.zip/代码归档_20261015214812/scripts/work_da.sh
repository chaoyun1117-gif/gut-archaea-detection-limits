#!/bin/bash
study=$1; grp=$2; run=$3; url=$4; dep=$5
case "$url" in http*) ;; *) url="https://$url" ;; esac
L=$(( dep*4000 ))
fq=/tmp/da_${run}_${dep}_$$
ok=0
for t in 1 2 3; do curl -sL --max-time 300 "$url" 2>/dev/null | zcat 2>/dev/null | head -$L > "$fq"; [ -s "$fq" ] && [ $(wc -l < "$fq") -ge 40 ] && { ok=1; break; }; sleep 2; done
if [ "$ok" != 1 ]; then printf "%s\t%s\t%s\t%d\tFAIL\t0\t0\n" "$study" "$grp" "$run" "$dep" >> "$OUT"; rm -f "$fq"; exit; fi
tot=$(( $(wc -l < "$fq")/4 ))
a=$(bowtie2 -x /home/admin/arch_db/arch_idx -U "$fq" -p 1 --no-unal 2>/dev/null | samtools view -F 4 -c -)
printf "%s\t%s\t%s\t%d\t%d\t%d\tOK\n" "$study" "$grp" "$run" "$dep" "$tot" "$a" >> "$OUT"
rm -f "$fq"
