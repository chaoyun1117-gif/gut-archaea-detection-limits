# -*- coding: utf-8 -*-
"""Apply reviewer-checklist items A3 (PRJNA763023 depth-adjusted result) and
C8 (research question = detection reliability, not pathogenicity) to EN + CN."""
import shutil

EN="SCI_Manuscript_EN_2026-10-13.md"; CN="SCI_Manuscript_CN_2026-10-13.md"
shutil.copyfile(EN, EN+".bak6"); shutil.copyfile(CN, CN+".bak6")

en=open(EN,encoding="utf-8").read(); cn=open(CN,encoding="utf-8").read()

# ---- A3 EN ----
a_old="In PRJNA763023, the CRC group had a lower median depth (33,724 reads) than the control group (54,137 reads)."
a_new=("In PRJNA763023, the CRC group had a lower median depth (33,724 reads) than the control group (54,137 reads); "
"depth was a strong predictor of detection in this cohort (odds ratio 16.2 per log10 reads; p=2.9×10⁻¹⁰), the "
"case–control detection contrast was not significant before adjustment (odds ratio 0.76; p=0.15) and remained "
"non-significant after adjustment for depth (odds ratio 0.91; p=0.62), and the abundance contrast among detected "
"samples was likewise null before (β=0.141; p=0.17) and after (β=0.122; p=0.24) adjustment. The weak case–control "
"difference in this shallow cohort is therefore attributable to depth, and the cohort does not contribute an "
"independent archaea–disease signal.")
assert en.count(a_old)==1, "EN A3 anchor"
en=en.replace(a_old,a_new)

# ---- C8 EN abstract ----
c_old="and assessed how this failure distorts downstream association and causal inference."
c_new=("and assessed how this failure distorts downstream association and causal inference. The question addressed "
"here is whether these associations can be reliably observed, not whether archaea cause disease.")
assert en.count(c_old)==1, "EN C8 abstract anchor"
en=en.replace(c_old,c_new)

# ---- C8 EN intro ----
i_old="as a diagnostic probe that exposes the detection failure."
i_new=("as a diagnostic probe that exposes the detection failure. The question is whether the association can be "
"reliably observed, not whether archaea are pathogenic.")
assert en.count(i_old)==1, "EN C8 intro anchor"
en=en.replace(i_old,i_new)

# ---- A3 CN ----
b_old="PRJNA763023 中 CRC 组中位深度（33,724）低于对照（54,137）。"
b_new=("PRJNA763023 中 CRC 组中位深度（33,724）低于对照（54,137）；该队列中深度是检出的强预测因子"
"（每 log10 读数 OR=16.2；p=2.9×10⁻¹⁰），病例—对照检出对比在调整前不显著（OR=0.76；p=0.15）、"
"在校正深度后仍不显著（OR=0.91；p=0.62），阳性样本内丰度对比调整前（β=0.141；p=0.17）与调整后"
"（β=0.122；p=0.24）同样为零。故该浅测序队列中微弱的病例—对照差异可归因于深度，不提供独立的古菌—疾病信号。")
assert cn.count(b_old)==1, "CN A3 anchor"
cn=cn.replace(b_old,b_new)

# ---- C8 CN abstract ----
d_old="并评估该失效如何系统性地扭曲下游关联与因果推断。"
d_new=("并评估该失效如何系统性地扭曲下游关联与因果推断。本文所问的是这些关联能否被可靠地观察到，"
"而非古菌是否致病。")
assert cn.count(d_old)==1, "CN C8 abstract anchor"
cn=cn.replace(d_old,d_new)

# ---- C8 CN intro ----
e_old="也是暴露该检出失效的诊断性探针。"
e_new=("也是暴露该检出失效的诊断性探针。本文要回答的是该关联能否被可靠地观察到，而非古菌是否致病。")
assert cn.count(e_old)==1, "CN C8 intro anchor"
cn=cn.replace(e_old,e_new)

open(EN,"w",encoding="utf-8").write(en)
open(CN,"w",encoding="utf-8").write(cn)
print("A3 + C8 applied to EN and CN.")

# sanity: abstracts/results still cite-free
import re
for f,tag in [(EN,"EN"),(CN,"CN")]:
    s=open(f,encoding="utf-8").read()
    ab=s[s.index("## Abstract" if tag=="EN" else "## 摘要"):s.index("## 1. Introduction" if tag=="EN" else "## 1 引言")]
    res=s[s.index("## 3. Results" if tag=="EN" else "## 3 结果"):s.index("## 4. Discussion" if tag=="EN" else "## 4 讨论")]
    print(tag,"cite in abstract:",bool(re.search(r"\[\d",ab)),"| cite in results:",bool(re.search(r"\[\d",res)))
PY