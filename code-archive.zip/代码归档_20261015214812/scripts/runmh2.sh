#!/bin/bash
cd /home/admin/arch_db
export OUT=/home/admin/arch_db/metahit_results.tsv
cat metahit_remaining.tsv | xargs -P 8 -n 4 /home/admin/arch_db/workmh.sh
echo "META_DONE $(wc -l < $OUT) $(date)" > /home/admin/arch_db/metahit_DONE.txt
