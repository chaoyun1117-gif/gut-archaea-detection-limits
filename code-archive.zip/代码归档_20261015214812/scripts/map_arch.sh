#!/bin/bash
run=$1; grp=$2; url=$3
fq=/tmp/${run}.fq
curl -sL --max-time 300 "$url" | zcat 2>/dev/null | head -2000000 > $fq
tot=$(( $(wc -l < $fq) / 4 ))
aln=$(bowtie2 -x arch_idx -U $fq -p 2 2>/dev/null | samtools view -F 4 -c -)
echo -e "$grp\t$run\t$tot\t$aln" >> arch_map_results.tsv
rm -f $fq
