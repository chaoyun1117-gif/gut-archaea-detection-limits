#!/bin/bash
grp=$1; run=$2; url=$3; out=${OUT:-/home/admin/arch_db/hall_results.tsv}
case "$url" in http*) ;; *) url="https://$url" ;; esac
fq=/tmp/h_${run}_$$
ok=0
for t in 1 2 3; do curl -sL --max-time 300 "$url" 2>/dev/null | zcat 2>/dev/null | head -2000000 > "$fq"; [ -s "$fq" ] && [ $(wc -l < "$fq") -ge 400 ] && { ok=1; break; }; sleep 2; done
if [ "$ok" != 1 ]; then printf "%s\t%s\tFAIL\t0\t0\n" "$grp" "$run" >> "$out"; rm -f "$fq"; exit; fi
tot=$(( $(wc -l < "$fq")/4 ))
a=$(bowtie2 -x /home/admin/arch_db/arch_idx -U "$fq" -p 1 --no-unal 2>/dev/null | samtools view -F 4 -c -)
printf "%s\t%s\t%d\t%d\tOK\n" "$grp" "$run" "$tot" "$a" >> "$out"
rm -f "$fq"
