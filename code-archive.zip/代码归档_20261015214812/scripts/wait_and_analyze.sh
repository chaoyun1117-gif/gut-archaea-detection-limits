#!/bin/bash
cd /home/admin/arch_db
for i in $(seq 1 360); do
  [ -f 16s_DONE.txt ] && break
  sleep 60
done
sleep 5
echo "=== DONE flag ==="; cat 16s_DONE.txt 2>/dev/null
echo "=== ANALYSIS ==="
python3 /home/admin/arch_db/analyze16s.py 2>&1 | tee /home/admin/arch_db/16s_analysis_report.txt
echo "ANALYSIS_COMPLETE"
