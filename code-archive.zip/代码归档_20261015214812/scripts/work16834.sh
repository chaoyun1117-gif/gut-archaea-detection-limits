#!/bin/bash
# args: grp run url ob ; out -> $OUT
grp=$1; run=$2; url=$3; ob=$4; out=${OUT:-/home/admin/arch_db/p16834_results.tsv}
case "$url" in http*) ;; *) url="https://$url" ;; esac
fq=/tmp/p16_${run}_$$
ok=0
for t in 1 2 3; do
  curl -sL --max-time 300 "$url" 2>/dev/null | zcat 2>/dev/null | head -4000000 > "$fq"
  [ -s "$fq" ] && [ $(wc -l < "$fq") -ge 400 ] && { ok=1; break; }
  sleep 2
done
if [ "$ok" != 1 ]; then printf "%s\t%s\t%s\tFAIL\t0\t0\t0\n" "$grp" "$run" "$ob" >> "$out"; rm -f "$fq"; exit; fi
tot=$(( $(wc -l < "$fq")/4 ))
read -r arc meth < <( bowtie2 -x /home/admin/arch_db/16s_arc_idx -U "$fq" -p 1 --no-unal 2>/dev/null \
  | samtools view -F 4 - 2>/dev/null | awk '{split($3,a,"|"); if(a[1]=="METH")m++; else if(a[1]=="ARCH")r++} END{print r+0,m+0}' )
printf "%s\t%s\t%s\t%d\t%d\t%d\tOK\n" "$grp" "$run" "$ob" "$tot" "$arc" "$meth" >> "$out"
rm -f "$fq"
