#!/bin/bash
cd /home/admin/arch_db
for i in $(seq 1 500); do [ -f metahit_DONE.txt ] && break; sleep 60; done
sleep 10
echo "=== DONE ==="; cat metahit_DONE.txt 2>/dev/null
python3 /home/admin/arch_db/analyzemh.py 2>&1 | tee /home/admin/arch_db/metahit_analysis.txt
echo "==MH_ANALYSIS_COMPLETE=="
