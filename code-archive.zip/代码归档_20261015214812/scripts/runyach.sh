#!/bin/bash
cd /home/admin/arch_db
export OUT=/home/admin/arch_db/yachida_results.tsv
echo -e "grp\trun\ttot\tarch\tstatus" > "$OUT"
cat yachida_input.tsv | xargs -P 4 -n 3 /home/admin/arch_db/workyach.sh
echo "YACH_DONE $(wc -l < "$OUT") $(date)" > /home/admin/arch_db/yachida_DONE.txt
