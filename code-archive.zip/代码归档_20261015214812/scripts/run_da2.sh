#!/bin/bash
cd /home/admin/arch_db
OUT=/home/admin/arch_db/da2_results.tsv; export OUT
echo -e "study\tgrp\trun\tdepth_rep\ttot\tarch" > "$OUT"
cat da2_input.tsv | xargs -P 4 -n 4 /home/admin/arch_db/work_da2.sh
echo "DA2_DONE $(wc -l < "$OUT") $(date)" > /home/admin/arch_db/da2_DONE.txt
