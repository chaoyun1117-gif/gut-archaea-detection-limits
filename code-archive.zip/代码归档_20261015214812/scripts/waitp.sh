#!/bin/bash
cd /home/admin/arch_db
for i in $(seq 1 500); do [ -f p16834_DONE.txt ] && break; sleep 30; done
sleep 10
echo "=== DONE ==="; cat p16834_DONE.txt 2>/dev/null
echo "=== failed ==="; awk -F'\t' 'NR>1 && $7!="OK"' p16834_results.tsv | wc -l
python3 /home/admin/arch_db/analyze16834.py 2>&1 | tee /home/admin/arch_db/p16834_analysis.txt
echo "==P16834_COMPLETE=="
