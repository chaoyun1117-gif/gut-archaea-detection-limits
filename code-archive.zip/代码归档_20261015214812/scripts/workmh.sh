#!/bin/bash
# args: cond run url subj ; out -> $OUT
cond=$1; run=$2; url=$3; subj=$4; out=${OUT:-/home/admin/arch_db/metahit_results.tsv}
case "$url" in http*) ;; *) url="https://$url" ;; esac
fq=/tmp/mh_${run}_$$
ok=0
for t in 1 2 3; do
  curl -sL --max-time 300 "$url" 2>/dev/null | zcat 2>/dev/null | head -2000000 > "$fq"
  [ -s "$fq" ] && [ $(wc -l < "$fq") -ge 400 ] && { ok=1; break; }
  sleep 2
done
if [ "$ok" != 1 ]; then printf "%s\t%s\t%s\tFAIL\t0\t0\n" "$cond" "$run" "$subj" >> "$out"; rm -f "$fq"; exit; fi
tot=$(( $(wc -l < "$fq")/4 ))
a=$(bowtie2 -x /home/admin/arch_db/arch_idx -U "$fq" -p 1 --no-unal 2>/dev/null | samtools view -F 4 -c -)
printf "%s\t%s\t%s\t%d\t%d\t%s\n" "$cond" "$run" "$subj" "$tot" "$a" "OK" >> "$out"
rm -f "$fq"
