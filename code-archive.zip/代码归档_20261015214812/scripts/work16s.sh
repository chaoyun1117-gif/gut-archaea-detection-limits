#!/bin/bash
# args: grp run url proj   ; output -> $OUT
grp=$1; run=$2; url=$3; proj=$4; out=${OUT:-/home/admin/arch_db/16s_full_results.tsv}
case "$url" in http*) ;; *) url="https://$url" ;; esac
fq=/tmp/fq_${run}_$$
ok=0
for try in 1 2 3; do
  curl -sL --max-time 300 "$url" 2>/dev/null | zcat 2>/dev/null > "$fq"
  if [ -s "$fq" ] && [ $(wc -l < "$fq") -ge 40 ]; then ok=1; break; fi
  sleep 2
done
if [ "$ok" != 1 ]; then printf "%s\t%s\t%s\tFAIL\t0\t0\t0\tNA\tNA\n" "$grp" "$run" "$proj" >> "$out"; rm -f "$fq"; exit; fi
tot=$(( $(wc -l < "$fq") / 4 ))
read -r arc meth < <( bowtie2 -x /home/admin/arch_db/16s_arc_idx -U "$fq" -p 1 --no-unal 2>/dev/null \
  | samtools view -F 4 - 2>/dev/null \
  | awk '{split($3,a,"|"); if(a[1]=="METH")m++; else if(a[1]=="ARCH")r++} END{print r+0, m+0}' )
arcfrac=$(awk -v a=$arc -v m=$meth -v t=$tot 'BEGIN{printf "%.8f",(t>0)?(a+m)/t:0}')
printf "%s\t%s\t%s\t%d\t%d\t%d\t%d\t%s\t%s\n" "$grp" "$run" "$proj" "$tot" "$arc" "$meth" "$((arc+meth))" "$arcfrac" "OK" >> "$out"
rm -f "$fq"
