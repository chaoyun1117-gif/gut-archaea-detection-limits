#!/bin/bash
cd /home/admin/arch_db
export OUT=/home/admin/arch_db/batch1_results.tsv
echo -e "study\tgrp\trun\ttot\tarch\tstatus" > "$OUT"
cat batch1_input.tsv | xargs -P 4 -n 4 /home/admin/arch_db/workbatch.sh
echo "BATCH1_DONE $(wc -l < "$OUT") $(date)" > /home/admin/arch_db/batch1_DONE.txt
