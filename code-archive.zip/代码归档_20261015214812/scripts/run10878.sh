#!/bin/bash
cd /home/admin/arch_db
export OUT=/home/admin/arch_db/p10878_results.tsv
echo -e "grp\trun\ttot\tarch\tstatus" > "$OUT"
cat p10878_input.tsv | xargs -P 4 -n 3 /home/admin/arch_db/work10878.sh
echo "P10878_DONE $(wc -l < "$OUT") $(date)" > /home/admin/arch_db/p10878_DONE.txt
