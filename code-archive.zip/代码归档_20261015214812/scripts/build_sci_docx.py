#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Markdown -> docx for the SCI manuscript (headings, paragraphs, md tables, inline images).
Usage: python3 build_sci_docx.py <in.md> <out.docx>
"""
import re, sys, os, tempfile
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
try:
    from PIL import Image
except Exception:
    Image = None

MAXW = int(os.environ.get('FIG_MAXW', '900'))
QUAL = int(os.environ.get('FIG_Q', '70'))

def prep_img(path):
    """Downscale to <=MAXW px wide and recompress as JPEG to keep the docx small."""
    if Image is None:
        return path
    try:
        im = Image.open(path).convert('RGB')
        if im.width > MAXW:
            im = im.resize((MAXW, int(im.height * MAXW / im.width)), Image.LANCZOS)
        tmp = tempfile.mktemp(suffix='.jpg')
        im.save(tmp, 'JPEG', quality=QUAL, optimize=True)
        return tmp
    except Exception:
        return path

md = open(sys.argv[1], encoding='utf-8').read().split('\n')
out = sys.argv[2]
d = Document()
st = d.styles['Normal']; st.font.name = 'Times New Roman'; st.font.size = Pt(11)

def is_sep(line):
    core = line.strip().strip('|')
    return bool(core) and all(ch in '-: ' for ch in core)

def add_runs(p, text, size=11):
    for pt in re.split(r'(\*\*.+?\*\*|\*[^*]+?\*)', text):
        if not pt:
            continue
        if pt.startswith('**') and pt.endswith('**'):
            r = p.add_run(pt[2:-2]); r.bold = True
        elif pt.startswith('*') and pt.endswith('*') and len(pt) > 2:
            r = p.add_run(pt[1:-1]); r.italic = True
        else:
            r = p.add_run(pt)
        r.font.name = 'Times New Roman'; r.font.size = Pt(size)
    if not p.runs:
        p.add_run('')

i = 0
while i < len(md):
    l = md[i]
    mimg = re.match(r'^!\[\]\(([^)]+)\)', l)
    if mimg:
        try:
            d.add_picture(prep_img(mimg.group(1)), width=Cm(16))
            d.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
        except Exception:
            add_runs(d.add_paragraph(), '[missing figure: %s]' % mimg.group(1), 9)
        i += 1; continue
    if l.startswith('|'):
        rows = []
        while i < len(md) and md[i].startswith('|'):
            if not is_sep(md[i]):
                rows.append([c.strip() for c in md[i].strip().strip('|').split('|')])
            i += 1
        if rows:
            ncol = max(len(r) for r in rows)
            t = d.add_table(rows=len(rows), cols=ncol)
            t.style = 'Table Grid'
            for ri, r in enumerate(rows):
                for ci in range(ncol):
                    cell = t.cell(ri, ci)
                    cell.text = ''
                    add_runs(cell.paragraphs[0], r[ci] if ci < len(r) else '', 9)
                    if ri == 0 and cell.paragraphs[0].runs:
                        cell.paragraphs[0].runs[0].bold = True
        continue
    m = re.match(r'^(#{1,3}) (.*)$', l)
    if m:
        lvl = len(m.group(1)); txt = m.group(2)
        h = d.add_heading('', level=(0 if lvl == 1 else lvl - 1))
        add_runs(h, txt, 16 if lvl == 1 else (14 if lvl == 2 else 12))
        for r in h.runs:
            r.font.name = 'Times New Roman'
        i += 1; continue
    if l.strip() == '' or l.strip() == '---':
        i += 1; continue
    add_runs(d.add_paragraph(), l)
    i += 1

d.save(out)
print('wrote', out)
