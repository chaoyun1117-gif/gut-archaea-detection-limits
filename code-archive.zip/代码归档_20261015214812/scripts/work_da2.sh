#!/bin/bash
study=$1; grp=$2; run=$3; url=$4
case "$url" in http*) ;; *) url="https://$url" ;; esac
pool=/tmp/pool_${run}_$$
curl -sL --max-time 600 "$url" 2>/dev/null | zcat 2>/dev/null | head -8000000 > "$pool"   # 2M reads pool
[ -s "$pool" ] || { echo -e "$study\t$grp\t$run\tNA\tFAIL\t0\t0" >> "$OUT"; rm -f "$pool"; exit; }
for D in 25 50 100 250 500; do
  for R in 1 2 3 4 5; do
    n=$((D*1000))
    sub=/tmp/sub_${run}_$$
    python3 - "$pool" "$sub" "$n" <<'PY'
import sys,random
pool,out,n=sys.argv[1],sys.argv[2],int(sys.argv[3])
recs=[]
with open(pool) as f:
    for line in f:
        h=line; s=f.readline(); p=f.readline(); q=f.readline()
        if not q: break
        recs.append(h+s+p+q)
random.seed(hash((pool,n,sys.argv[0]))&0xffff)
idx=sorted(random.sample(range(len(recs)),min(n,len(recs))))
with open(out,'w') as o:
    for i in idx: o.write(recs[i])
PY
    tot=$(( $(wc -l < "$sub")/4 ))
    a=$(bowtie2 -x /home/admin/arch_db/arch_idx -U "$sub" -p 1 --no-unal 2>/dev/null | samtools view -F 4 -c -)
    echo -e "$study\t$grp\t$run\t${D}k_rep${R}\t$tot\t$a" >> "$OUT"
    rm -f "$sub"
  done
done
rm -f "$pool"
