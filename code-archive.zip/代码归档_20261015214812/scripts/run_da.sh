#!/bin/bash
cd /home/admin/arch_db
echo -e "study\tgrp\trun\tdep\ttot\tarch\tstatus" > da_results.tsv
export OUT=/home/admin/arch_db/da_results.tsv
for D in 25 50 100 250; do
  echo "=== depth ${D}k ===" >> da_run.log
  awk -v d=$D -F'\t' '{print $1"\t"$2"\t"$3"\t"$4"\t"d}' da_input.tsv | xargs -P 4 -n 5 /home/admin/arch_db/work_da.sh
done
echo "DA_DONE $(wc -l < da_results.tsv) $(date)" > /home/admin/arch_db/da_DONE.txt
