#!/bin/bash
cd /home/admin/arch_db
: > arch_map_results.tsv
# CRC
tail -n +2 crc_runs.tsv | while IFS=$'\t' read run ftp; do
  u="https://$(echo $ftp | cut -d';' -f1)"; ./map_arch.sh "$run" CRC "$u"
done
# IBD
tail -n +2 ibd_runs.tsv | while IFS=$'\t' read run ftp; do
  u="https://$(echo $ftp | cut -d';' -f1)"; ./map_arch.sh "$run" IBD "$u"
done
echo DONE_MAP
