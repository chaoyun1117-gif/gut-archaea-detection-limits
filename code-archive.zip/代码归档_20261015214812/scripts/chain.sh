#!/bin/bash
cd /home/admin/arch_db
# wait for p16834
for i in $(seq 1 400); do [ -f p16834_DONE.txt ] && break; sleep 20; done
# 1) PRJDB11845 (16S)
export OUT=/home/admin/arch_db/p11845_results.tsv
echo -e "grp\trun\ttot\tarch\tmeth\tstatus" > "$OUT"
cat p11845_input.tsv | xargs -P 4 -n 3 /home/admin/arch_db/work11845.sh
echo "P11845_DONE $(wc -l < "$OUT") $(date)" > /home/admin/arch_db/p11845_DONE.txt
# 2) Qin (WGS)
export OUT=/home/admin/arch_db/qin_results.tsv
echo -e "grp\trun\ttot\tarch\tstatus" > "$OUT"
cat qin_input.tsv | xargs -P 4 -n 3 /home/admin/arch_db/workqin.sh
echo "QIN_DONE $(wc -l < "$OUT") $(date)" > /home/admin/arch_db/qin_DONE.txt
echo "CHAIN_DONE"
