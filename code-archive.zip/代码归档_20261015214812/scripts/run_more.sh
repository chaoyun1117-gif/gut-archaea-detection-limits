#!/bin/bash
cd /home/admin/arch_db
while IFS=$'\t' read grp run ftp; do
  [ -z "$run" ] && continue
  u="https://$(echo "$ftp" | cut -d';' -f1)"
  fq=/tmp/${run}.fq
  curl -sL --max-time 300 "$u" | zcat 2>/dev/null | head -2000000 > $fq
  tot=$(( $(wc -l < $fq) / 4 ))
  if [ "$tot" -lt 1000 ]; then echo -e "$grp\t$run\tSKIP\t0" >> arch_map2.tsv; rm -f $fq; continue; fi
  aln=$(bowtie2 -x arch_idx -U $fq -p 2 2>/dev/null | samtools view -F 4 -c -)
  echo -e "$grp\t$run\t$tot\t$aln" >> arch_map2.tsv
  rm -f $fq
done < more_runs.tsv
echo DONE_MORE
