#!/bin/bash
cd /home/admin/arch_db
mkdir -p mbarc
for r in 1 2; do
  u="https://ftp.sra.ebi.ac.uk/vol1/fastq/SRR365/005/SRR3656745/SRR3656745_${r}.fastq.gz"
  curl -sL --max-time 1800 "$u" 2>/dev/null | zcat 2>/dev/null | head -4000000 > mbarc/wgs_${r}.fq
done
echo "WGS_DONE $(date)" > mbarc/DL_DONE.txt
