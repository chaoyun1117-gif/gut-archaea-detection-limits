#!/bin/bash
# usage: map16s.sh run grp url outfile
run=$1; grp=$2; url=$3; out=$4
fq=/tmp/${run}.fq
curl -sL --max-time 600 "$url" 2>/dev/null | zcat 2>/dev/null > $fq
if [ ! -s "$fq" ]; then printf "%s\t%s\t0\t0\t0\t0\t0\t0\tNA\n" "$grp" "$run" >> "$out"; rm -f $fq; exit; fi
tot=$(( $(wc -l < $fq) / 4 ))
rl=$(awk 'NR==2{print length($0); exit}' $fq)
bowtie2 -x /home/admin/arch_db/16s_dom_idx -U $fq --local -p 2 --no-unal 2>/dev/null \
  | samtools view -F 4 - 2>/dev/null \
  | awk -v tot=$tot -v run=$run -v grp=$grp -v rl=$rl '
    { split($3,a,"|"); d=a[1];
      if(d=="METH"){meth++} else if(d=="ARCH"){arch++} else if(d=="BACT"){bac++}
      n++ }
    END{
      denom=(arch+meth+bac);
      frac=(denom>0)?(arch+meth)/denom:0;
      printf "%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%.6f\n", grp,run,tot,rl,n,bac,arch,meth,frac
    }' >> "$out"
rm -f $fq
