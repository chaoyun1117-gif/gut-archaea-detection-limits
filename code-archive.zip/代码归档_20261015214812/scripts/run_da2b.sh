#!/bin/bash
cd /home/admin/arch_db
export OUT=/home/admin/arch_db/da2_results.tsv
cat da2_remaining.tsv | xargs -P 4 -n 4 /home/admin/arch_db/work_da2.sh
echo "DA2B_DONE $(wc -l < "$OUT") $(date)" > /home/admin/arch_db/da2_DONE.txt
