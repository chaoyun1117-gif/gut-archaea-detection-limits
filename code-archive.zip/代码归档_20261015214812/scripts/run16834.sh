#!/bin/bash
cd /home/admin/arch_db
export OUT=/home/admin/arch_db/p16834_results.tsv
echo -e "grp\trun\tob\ttot\tarch\tmeth\tstatus" > "$OUT"
cat p16834_input.tsv | xargs -P 4 -n 4 /home/admin/arch_db/work16834.sh
echo "P16834_DONE $(wc -l < "$OUT") $(date)" > /home/admin/arch_db/p16834_DONE.txt
