# 分析代码归档（投稿配套）
- scripts/: 重写脚本(rewrite_*)、A3/C8 补漏脚本、docx 生成器(build_sci_docx.py)、原始读长定量脚本(arch_db *.sh)、逐样本 16S 结果(16s_full_results.tsv) 与输入清单(all16s_input.tsv)
- refs_list.txt: 核验后的参考文献库；数据提取表_T1_主表.csv、队列重叠核对表.csv: 主表与补充表 S1
- 说明：投稿前建议将本归档上传 Zenodo/GitHub 获取 DOI，并在 Data Availability 中引用。
