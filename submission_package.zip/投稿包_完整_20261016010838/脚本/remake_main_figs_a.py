# -*- coding: utf-8 -*-
"""Regenerate the main figures in the spec-compliant style (170 mm, 7.5 pt, no tight)."""
import json, math, csv
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import fig_style as FS

OUT = "figures/"
pool = json.load(open('/tmp/meta_pool.json'))
forest = json.load(open('/tmp/forest.json'))
trimfill = json.load(open('/tmp/trimfill.json'))

def gJ(n1, n2):  # small-sample correction factor
    df = n1 + n2 - 2
    return 1 - 3.0/(4*df - 1)

# ---------------- Fig 5: pooled forest by phenotype ----------------
FS.apply()
order = sorted(pool, key=lambda g: -pool[g][3])
fig = plt.figure(figsize=(FS.WIN, 0.62*len(order)+1.5))
ax = fig.add_axes([0.30, 0.16, 0.66, 0.78])
y=0; yt=[]; yl=[]
for gg in order:
    mu,se,I2,k,es = pool[gg]
    ax.plot([mu-1.96*se, mu+1.96*se],[y,y], color='#333', lw=0.9)
    ax.plot(mu,y,'D', color='#c0392b', ms=4)
    yt.append(y); yl.append('%s  k=%d  I²=%.0f%%'%(gg,k,I2)); y-=1
ax.axvline(0, color='#999', lw=0.6, ls='--')
ax.set_yticks(yt); ax.set_yticklabels(yl)
ax.set_xlabel("Hedges' g (disease vs healthy)")
for t,l in zip(ax.get_yticklabels(), yl): t.set_fontweight('bold')
FS.save(fig, OUT+'fig_forest_pooled.png')

# ---------------- Fig 6: within-study forest CRC (A) / IBD (B) ----------------
byd = defaultdict(list)
for s,g,n1,n2,gg,se in forest: byd[g].append((s,n1,n2,gg,se))
def forest_panel(ax, items, pooled_label):
    items = sorted(items, key=lambda x:x[3])
    y=0; yt=[]; yl=[]
    for s,n1,n2,gg,se in items:
        ax.plot([gg-1.96*se, gg+1.96*se],[y,y], color='#555', lw=0.7)
        ax.plot(gg,y,'o', color='#2c5f8a', ms=3)
        yt.append(y); yl.append('%s (%d/%d)'%(s,n1,n2)); y-=1
    ax.axvline(0, color='#999', lw=0.6, ls='--')
    ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=6.5)
    return y
fig = plt.figure(figsize=(FS.WIN, 4.2))
axA = fig.add_axes([0.30, 0.55, 0.66, 0.40]); forest_panel(axA, byd['CRC'], 'CRC')
axA.set_title('A  CRC', loc='left', fontweight='bold')
axB = fig.add_axes([0.30, 0.08, 0.66, 0.36]); forest_panel(axB, byd['IBD'], 'IBD')
axB.set_title('B  IBD', loc='left', fontweight='bold')
axB.set_xlabel("Hedges' g (case vs control)")
FS.save(fig, OUT+'FIG1_forest.png')

# ---------------- Fig 12/13/14: funnel, trimfill, influence (CRC) ----------------
es = pool['CRC'][4]
ys = np.array([e[1] for e in es]); ses = np.array([e[2] for e in es])
mu = pool['CRC'][0]
FS.apply()
fig = plt.figure(figsize=(70/25.4, 2.6))
ax = fig.add_axes([0.20, 0.20, 0.74, 0.72])
ax.scatter(ys, ses, color='#2c5f8a', s=12)
ax.axvline(mu, color='#c0392b', lw=0.9)
ax.set_xlabel("Hedges' g"); ax.set_ylabel("SE"); ax.invert_yaxis()
FS.save(fig, OUT+'fig_funnel_CRC.png')

FS.apply()
fig = plt.figure(figsize=(70/25.4, 2.6))
ax = fig.add_axes([0.20, 0.20, 0.74, 0.72])
adj = trimfill['CRC']['adj_g']; ci = trimfill['CRC']['adj_ci']
ax.scatter(ys, ses, color='#888', s=12)
ax.axvline(pool['CRC'][0], color='#c0392b', lw=0.9, label='observed')
ax.axvline(adj, color='#2c5f8a', lw=0.9, ls='--', label='trim-fill (k0=0)')
ax.set_xlabel("Hedges' g"); ax.set_ylabel("SE"); ax.invert_yaxis(); ax.legend(frameon=False)
FS.save(fig, OUT+'fig_trimfill_CRC.png')

# influence (leave-one-out) for CRC
loo=[]
for i in range(len(es)):
    keep=[e for j,e in enumerate(es) if j!=i]
    w=sum(1/(e[2]**2) for e in keep); m=sum(e[1]/e[2]**2 for e in keep)/w
    loo.append((es[i][0], m))
FS.apply()
fig = plt.figure(figsize=(70/25.4, 2.8))
ax = fig.add_axes([0.32, 0.22, 0.62, 0.70])
loo_sorted = sorted(loo, key=lambda x:x[1])
for i,(s,m) in enumerate(loo_sorted):
    ax.plot(m, i, 'o', color='#2c5f8a', ms=3.5)
ax.axvline(pool['CRC'][0], color='#c0392b', lw=0.9)
ax.set_yticks(range(len(loo_sorted))); ax.set_yticklabels([s for s,_ in loo_sorted], fontsize=6.5)
ax.set_xlabel("pooled g (leave-one-out)")
FS.save(fig, OUT+'fig_doiplot_CRC.png')
print("forest/funnel/trimfill/influence done")
