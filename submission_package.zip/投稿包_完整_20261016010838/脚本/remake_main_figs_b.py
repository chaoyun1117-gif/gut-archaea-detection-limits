# -*- coding: utf-8 -*-
"""Main figures batch B, spec style."""
import json, math, csv
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
import fig_style as FS
OUT="figures/"

# ---------------- Fig 2: detection map (dataset detection vs depth) ----------------
data = [  # label, type, median reads, detection %
 ("PRJEB10878","WGS",5.9e7,66),("PRJDB4176","WGS",4.4e7,28),("PRJNA385949","WGS",3.0e7,21),
 ("PRJEB1220","WGS",5.7e7,91),("PRJNA398089","WGS",2.3e7,10),
 ("PRJEB53891","16S",1.8e5,100),("PRJDB16834","16S",4.8e6,100),("PRJNA763023","16S",5.5e4,12),
 ("PRJDB11845","16S",3.6e4,0)]
col={'WGS':'#2c5f8a','16S':'#c0392b'}
FS.apply()
fig=plt.figure(figsize=(FS.WIN,2.6))
ax=fig.add_axes([0.09,0.22,0.88,0.70])
for lab,t,d,det in data:
    ax.scatter(d,det,color=col[t],s=22,marker=('o' if t=='WGS' else '^'))
ax.set_xscale('log'); ax.set_xlabel('sequencing depth (median reads)'); ax.set_ylabel('archaeal detection (%)')
for t in ['WGS','16S']:
    ax.scatter([],[],color=col[t],s=22,marker=('o' if t=='WGS' else '^'),label=t)
ax.legend(frameon=False); ax.set_ylim(-5,105)
FS.save(fig, OUT+'fig4_detection.png')

# ---------------- Fig 3: depth attenuation ----------------
rows=list(csv.DictReader(open('da2_results.tsv'),delimiter='\t'))
by=defaultdict(lambda: defaultdict(list))
for r in rows:
    lab=r['depth_rep'].split('_')[0]
    by[(r['study'],lab)][r['grp']].append(float(r['arch']))
def lo(x): return math.log10(x/ (r['tot'] and 1) )  # placeholder
def gval(a,b):
    a=np.array(a); b=np.array(b)
    if len(a)<2 or len(b)<2: return (np.nan,np.nan,np.nan)
    n1,n2=len(a),len(b); m1,m2=a.mean(),b.mean(); s1,s2=a.std(ddof=1),b.std(ddof=1)
    sp=math.sqrt(((n1-1)*s1*s1+(n2-1)*s2*s2)/(n1+n2-2))
    if sp==0: return (0.0,0.0,0.0)
    d=(m1-m2)/sp*(1-3/(4*(n1+n2)-9))
    se=math.sqrt((n1+n2)/(n1*n2)+d*d/(2*(n1+n2)))
    return (d,se,se*1.96)
order_depth=['25k','50k','100k','250k','500k']
study_label={'P10878':'China (PRJEB10878)','PDB4176':'Japan (PRJDB4176)'}
FS.apply()
fig=plt.figure(figsize=(FS.WIN,2.8))
axA=fig.add_axes([0.08,0.22,0.40,0.70]); axB=fig.add_axes([0.58,0.22,0.38,0.70])
for st in ['P10878','PDB4176']:
    xs=[];det=[];gv=[];gs=[];xpos=[]
    for i,dl in enumerate(order_depth):
        grp=by.get((st,dl))
        if not grp: continue
        tot=sum(len(v) for v in grp.values())
        pos=sum(1 for v in grp.get('case',[]) if v>=1)+sum(1 for v in grp.get('control',[]) if v>=1)
        det.append(100*pos/tot); xpos.append(i)
        d,se,ci=gval(np.log10(np.array(grp.get('case',[0]))+1e-6), np.log10(np.array(grp.get('control',[0]))+1e-6))
        gv.append(d); gs.append(se)
    axA.plot(xpos,det,'o-',lw=1.0,ms=3.5,label=study_label[st])
    axB.errorbar(xpos,gv,yerr=[1.96*s for s in gs],fmt='o-',lw=1.0,ms=3.5,capsize=2,label=study_label[st])
axA.set_xticks(range(len(order_depth))); axA.set_xticklabels(order_depth)
axA.set_xlabel('analysis depth (reads)'); axA.set_ylabel('detection (%)'); axA.set_title('A',loc='left',fontweight='bold'); axA.legend(frameon=False,fontsize=6.5)
axB.set_xticks(range(len(order_depth))); axB.set_xticklabels(order_depth)
axB.set_xlabel('analysis depth (reads)'); axB.set_ylabel("Hedges' g (CRC vs control)"); axB.axhline(0,color='#999',lw=0.5,ls=':'); axB.set_title('B',loc='left',fontweight='bold'); axB.legend(frameon=False,fontsize=6.5)
FS.save(fig, OUT+'fig_depth_attenuation.png')

# ---------------- Fig 4: literature methane positivity by phenotype ----------------
pheno=[('IGT',38),('T2D',30),('CRC',29),('Adenoma',29),('CVD',20),('IBD',8),('Hypertension',3)]
FS.apply()
fig=plt.figure(figsize=(70/25.4,2.6))
ax=fig.add_axes([0.30,0.20,0.66,0.72])
ys=list(range(len(pheno))); vals=[p[1] for p in pheno]
ax.barh(ys, vals, color='#7fae8f', edgecolor='#3d6b4e', lw=0.5)
ax.set_yticks(ys); ax.set_yticklabels([p[0] for p in pheno]); ax.invert_yaxis()
ax.set_xlabel('reported methane positivity (%)')
for i,v in enumerate(vals): ax.text(v+0.5,i,'%d'%v,va='center',fontsize=6.5)
FS.save(fig, OUT+'fig_aline_rates.png')

# ---------------- Fig 7: detection-probability model vs depth ----------------
b0, b1 = -10.29, 1.25   # Table 2 unadjusted logistic
xs=np.logspace(3,9,200); p=1/(1+np.exp(-(b0+b1*np.log10(xs))))
FS.apply()
fig=plt.figure(figsize=(70/25.4,2.6))
ax=fig.add_axes([0.17,0.21,0.79,0.72])
ax.plot(xs,p*100,color='#2c5f8a',lw=1.1)
ax.axhline(50,color='#999',lw=0.6,ls='--')
ax.set_xscale('log'); ax.set_xlabel('sequencing depth (reads)'); ax.set_ylabel('predicted detection (%)')
ax.set_ylim(0,100)
FS.save(fig, OUT+'FIG_det_adequacy.png')

# ---------------- Fig 8: raw-read WGS forest ----------------
from scipy.stats import norm
def se_from_p(g,p): 
    z=norm.isf(p/2); return abs(g)/z
wr=[("PRJEB10878 CRC (China)",0.315,0.0139),("PRJDB4176 CRC (Japan)",0.158,0.0227),
 ("PRJDB4176 Adenoma (Japan)",0.242,0.0123),("FengQ_2015 CRC",0.660,0.001),
 ("HanniganGD_2017 CRC",0.345,0.20),("WirbelJ_2018 CRC",0.051,0.84),("ZellerG_2014 CRC",0.042,0.82),
 ("MetaHIT/PRJEB1220 IBD",-0.130,0.097),("PRJNA385949 IBD",0.084,0.373)]
items=[(n,g,se_from_p(g,p)) for n,g,p in wr]+[("Pooled CRC",0.265,(0.438-0.093)/(2*1.96))]
FS.apply()
fig=plt.figure(figsize=(70/25.4,3.2))
ax=fig.add_axes([0.52,0.20,0.40,0.72])
y=0; yt=[]; yl=[]
for n,g,se in items:
    pooled = n.startswith('Pooled')
    ax.plot([g-1.96*se,g+1.96*se],[y,y],color=('#000' if pooled else '#555'),lw=(1.0 if pooled else 0.7))
    ax.plot(g,y,('D' if pooled else 'o'),color=('#c0392b' if pooled else '#2c5f8a'),ms=(4 if pooled else 3))
    yt.append(y); yl.append(n); y-=1
ax.axvline(0,color='#999',lw=0.6,ls='--')
ax.set_yticks(yt); ax.set_yticklabels(yl,fontsize=6.3)
for t,l in zip(ax.get_yticklabels(),yl):
    if l.startswith('Pooled'): t.set_fontweight('bold')
ax.set_xlabel("Hedges' g")
FS.save(fig, OUT+'FIG2_rawline.png')

# ---------------- Fig 10: DNA vs RNA methanogenesis ----------------
FS.apply()
fig=plt.figure(figsize=(70/25.4,2.4))
ax=fig.add_axes([0.20,0.24,0.72,0.66])
ax.bar([0,1],[1.0,2.7],color=['#9ecae1','#fc9272'],edgecolor='#333',lw=0.5)
ax.set_xticks([0,1]); ax.set_xticklabels(['DNA positive','RNA positive'])
ax.set_ylabel('HMP2 samples (%)')
for x,v in zip([0,1],[1.0,2.7]): ax.text(x,v+0.07,'%.1f%%'%v,ha='center',fontsize=6.5)
FS.save(fig, OUT+'fig_RNA_DNA.png')

# ---------------- Fig 11: MR power vs OR ----------------
ORS=np.linspace(1.0,1.4,60); z=1.959964
# crude power from logOR / SE (SE chosen so that OR=1.14 → power 0.8)
se=(math.log(1.14))/(1.959964+0.8416)
pw=[1-norm.cdf(z-math.log(o)/se)+norm.cdf(-z-math.log(o)/se) for o in ORS]
FS.apply()
fig=plt.figure(figsize=(70/25.4,2.6))
ax=fig.add_axes([0.17,0.21,0.79,0.72])
ax.plot(ORS,[p*100 for p in pw],color='#2c5f8a',lw=1.1)
ax.axhline(80,color='#999',lw=0.6,ls='--'); ax.axvline(1.14,color='#999',lw=0.6,ls=':')
ax.axvline(1.06,color='#c0392b',lw=0.9)
ax.set_xlabel('true OR (per 1-SD exposure)'); ax.set_ylabel('statistical power (%)'); ax.set_ylim(0,100)
FS.save(fig, OUT+'FIG3_mr_power.png')
print("batch B done")
