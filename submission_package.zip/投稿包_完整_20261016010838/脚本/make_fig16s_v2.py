# -*- coding: utf-8 -*-
"""16S raw-read line figure, spec-compliant restyle of the 'Fair'-graded triple panel.
Fixes: panel A group-label crowding; clearer group structure; unified 7.5 pt; 170 mm; no tight."""
import csv, math, numpy as np
import matplotlib.pyplot as plt
import fig_style

rows=[]
for r in csv.DictReader(open('/home/admin/arch_db/16s_full_results.tsv'), delimiter='\t'):
    if r['status']!='OK': continue
    rows.append({'grp':r['grp'],'proj':r['proj'],'tot':int(r['tot']),'arc':int(r['arc_tot']),'frac':float(r['arcfrac'])})
def sel(p,g): return [x for x in rows if x['proj']==p and x['grp']==g]

fig_style.apply()
fig = plt.figure(figsize=(fig_style.WIN, 2.75))
gs = fig.add_gridspec(1,3, width_ratios=[1.05,1.0,1.0], wspace=0.55,
                      left=0.075, right=0.985, top=0.85, bottom=0.30)

# ---- Panel A: archaeal 16S fraction by project/group ----
ax=fig.add_subplot(gs[0])
groups=[('PRJEB53891','Ctrl'),('PRJEB53891','CRC'),('PRJNA763023','Ctrl'),('PRJNA763023','CRC')]
xs=[0,0.75,2.0,2.75]
for x,(p,g) in zip(xs,groups):
    vals=[math.log10(v['frac']+1e-6) for v in sel(p,g)]
    bp=ax.boxplot([vals], positions=[x], widths=0.55, showfliers=False,
                  patch_artist=True, medianprops=dict(color='k', lw=0.8))
    bp['boxes'][0].set(facecolor=('#9ecae1' if g=='Ctrl' else '#fc9272'), edgecolor='k', lw=0.5)
    jit=(np.random.RandomState(0).rand(len(vals))-0.5)*0.22
    ax.scatter(np.full(len(vals),x)+jit, vals, s=2.5,
               c=('#4292c6' if g=='Ctrl' else '#de2d26'), alpha=0.45, linewidths=0)
ax.set_xticks(xs); ax.set_xticklabels(['Ctrl','CRC','Ctrl','CRC'])
ax.set_ylabel('log$_{10}$ archaeal fraction')
ax.set_title('A', loc='left', fontweight='bold')
ax.set_xlim(-0.5,3.25)
ax.text(0.375,-0.28,'P1 deep 16S', transform=ax.transAxes, ha='center', fontsize=6.6, color='#555')
ax.text(0.83,-0.28,'P2 shallow 16S', transform=ax.transAxes, ha='center', fontsize=6.6, color='#555')
ax.axhline(math.log10(1e-6), color='#999', lw=0.4, ls=':')

# ---- Panel B: detection vs depth (P2) ----
ax=fig.add_subplot(gs[1])
xr=[x for x in rows if x['proj']=='PRJNA763023']; xr.sort(key=lambda x:x['tot']); n=len(xr)
terc=[]; prev=[]
for i in range(3):
    seg=xr[i*n//3:(i+1)*n//3]
    terc.append(seg[len(seg)//2]['tot']); prev.append(sum(1 for x in seg if x['arc']>0)/len(seg)*100)
ax.plot(range(3), prev, 'o-', color='#238b45', lw=1.0, ms=3.6)
ax.set_xticks(range(3)); ax.set_xticklabels(['%.0fk'%(t/1000) for t in terc])
ax.set_xlabel('sequencing depth (median reads)'); ax.set_ylabel('archaeal detection (%)')
for i,v in enumerate(prev): ax.text(i, v+1.0, '%.1f'%v, ha='center', fontsize=6.4)
ax.set_ylim(0, max(prev)*1.5)
ax.set_title('B', loc='left', fontweight='bold')

# ---- Panel C: effect sizes ----
ax=fig.add_subplot(gs[2])
items=[('P1 (deep)',(0.735,0.400)),('P2 (shallow)',(-0.055,0.062)),('Pooled',(0.241,0.382))]
for i,(lab,(g,se)) in enumerate(items):
    y=len(items)-1-i
    mk='D' if lab=='Pooled' else 's'
    ax.errorbar(g, y, xerr=1.96*se, fmt=mk, color='k' if lab=='Pooled' else '#333', ms=4, capsize=2, lw=0.8)
ax.axvline(0, color='#999', lw=0.5, ls='--')
ax.set_yticks(range(len(items))); ax.set_yticklabels([l for l,_ in items][::-1])
ax.set_xlabel("Hedges' g (log$_{10}$ frac)"); ax.set_xlim(-1.2,1.8)
ax.set_title('C', loc='left', fontweight='bold')

fig_style.save(fig, 'figures/fig_16s_withinproject.png')
