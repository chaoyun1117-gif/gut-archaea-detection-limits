# -*- coding: utf-8 -*-
"""PRISMA 2020 flow — spec-compliant restyle of the 'Fair' diagram.
Fixes: side-box text overlap/clipping; unified 7.5 pt; 170 mm; no bbox_inches='tight'.
NOTE: the terminal count is rendered as in the source script (n=150); it conflicts with
the main text (155) and must be reconciled by the authors (checklist C1/C2)."""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import fig_style

fig_style.apply()
fig = plt.figure(figsize=(fig_style.WIN, 7.0))
ax = fig.add_axes([0.02, 0.02, 0.96, 0.96]); ax.set_xlim(0,12); ax.set_ylim(0,24); ax.axis('off')

def box(x,y,w,h,txt,fc='#eef4fb',ec='#2c5f8a',fs=6.6):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.06,rounding_size=0.08',fc=fc,ec=ec,lw=0.7))
    ax.text(x+w/2,y+h/2,txt,ha='center',va='center',fontsize=fs)
def side(x,y,w,h,txt):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.06,rounding_size=0.08',fc='#f5f5f5',ec='#9a9a9a',lw=0.6))
    ax.text(x+w/2,y+h/2,txt,ha='center',va='center',fontsize=6.0,color='#444')
def arrow(x1,y1,x2,y2): ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=7,lw=0.7,color='#2c5f8a'))

for lbl,y in [('Identification',23.2),('Screening',17.8),('Eligibility',11.0),('Included',4.6)]:
    ax.text(0.1,y,lbl,fontsize=7.5,fontweight='bold',color='#2c5f8a',rotation=90,va='top')

xc, wc = 3.0, 4.0
side_x, side_w = 7.8, 3.6
# Identification
box(xc,22.0,wc,1.5,'Records identified\nEurope PMC (n = 147) · PubMed (n = 95)')
box(xc,20.2,wc,1.1,'Records after duplicates removed (n = 183)')
side(side_x,22.0,side_w,1.0,'Duplicates removed\n(n = 59)')
arrow(xc+wc/2,22.0,xc+wc/2,21.3)
# Screening
box(xc,18.6,wc,1.1,'Records screened (n = 183)')
arrow(xc+wc/2,20.2,xc+wc/2,19.7)
box(xc,17.0,wc,1.1,'Expanded abstract corpus assessed (n = 602)')
side(side_x,17.0,side_w,1.4,'Records excluded (n = 451)\nnon-human (n = 102)\nno archaea / methane\nindicator (n = 163)')
arrow(xc+wc/2,18.6,xc+wc/2,18.1)
# Eligibility
box(xc,15.2,wc,1.1,'Reports sought for retrieval (n = 151)')
arrow(xc+wc/2,17.0,xc+wc/2,16.3)
box(xc,13.6,wc,1.1,'Full-text reports assessed\nfor eligibility (n = 155)')
side(side_x,15.2,side_w,0.9,'Reports not retrieved\n(n = 1)')
side(side_x,13.2,side_w,1.0,'Additional records via\nreference lists (n = 5)')
arrow(xc+wc/2,15.2,xc+wc/2,14.7)
side(side_x,13.6,side_w,0.9,'Full-text excluded (n = 0)')
# Included
box(xc,11.6,wc,1.2,'Studies included in qualitative synthesis (n = 155)')
arrow(xc+wc/2,13.6,xc+wc/2,12.8)
box(xc,9.6,wc,1.4,'Studies included in quantitative synthesis\n(meta-analysis)\n(n = 110 studies; 28,445 samples)')
arrow(xc+wc/2,11.6,xc+wc/2,11.0)
ax.text(0.1,0.6,'PRISMA 2020 flow of study selection',fontsize=6.2,color='#777')
eq = 1
fig_style.save(fig, 'figures/fig_prisma.png')
