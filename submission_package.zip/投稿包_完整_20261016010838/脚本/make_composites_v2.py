# -*- coding: utf-8 -*-
"""Rebuild the 6 composite figures with UNIQUE sequential panel letters (A,B,C,D...).
No inner sub-figure letters. 600 dpi, 170 mm wide, 1:1."""
import json, math, csv
from collections import defaultdict
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from scipy import stats

W = 170/25.4          # 6.693 in
FS = 7.5
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":FS,"axes.titlesize":FS,
 "axes.labelsize":FS,"xtick.labelsize":FS,"ytick.labelsize":FS,"legend.fontsize":FS,
 "axes.linewidth":0.6,"xtick.major.width":0.6,"ytick.major.width":0.6,
 "figure.dpi":600,"savefig.dpi":600,"figure.facecolor":"white","savefig.facecolor":"white"})
OUT="图片_拼图/"

def lab(ax, s): ax.set_title(s, loc="left", fontweight="bold")

def save(fig, name):
    fig.savefig(OUT+name, dpi=600, facecolor="white")
    try: fig.savefig(OUT+name.replace(".png",".pdf"), format="pdf", facecolor="white")
    except Exception as e: print("pdf err", e)
    plt.close(fig); print("wrote", name)

pool=json.load(open('/tmp/meta_pool.json')); forest=json.load(open('/tmp/forest.json'))
trimfill=json.load(open('/tmp/trimfill.json'))
def se_from_p(g,p):
    z=stats.norm.isf(p/2); return abs(g)/z if z else 0

# ---------- helpers ----------
def forest_ax(ax, items, xlabel="Hedges' g"):
    y=0; yt=[]; yl=[]
    for n,g,se in items:
        pooled=n.lower().startswith("pooled")
        ax.plot([g-1.96*se,g+1.96*se],[y,y],color=("#000" if pooled else "#555"),lw=(1.0 if pooled else 0.7))
        ax.plot(g,y,("D" if pooled else "o"),color=("#c0392b" if pooled else "#2c5f8a"),ms=(4 if pooled else 3))
        yt.append(y); yl.append(n); y-=1
    ax.axvline(0,color="#999",lw=0.6,ls="--")
    ax.set_yticks(yt); ax.set_yticklabels(yl,fontsize=6.5)
    for t,l in zip(ax.get_yticklabels(),yl):
        if l.lower().startswith("pooled"): t.set_fontweight("bold")
    ax.set_xlabel(xlabel)

# ================= Figure 1 : A PRISMA, B methane positivity =================
fig=plt.figure(figsize=(W, 8.2))
gs=fig.add_gridspec(2,1, height_ratios=[2.4,1], hspace=0.28, left=0.22,right=0.97,top=0.96,bottom=0.05)
ax=fig.add_subplot(gs[0]); ax.set_xlim(0,12); ax.set_ylim(0,20); ax.axis("off")
def box(x,y,w,h,txt,fc="#eef4fb",ec="#2c5f8a",fs=6.6):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.06,rounding_size=0.08",fc=fc,ec=ec,lw=0.7))
    ax.text(x+w/2,y+h/2,txt,ha="center",va="center",fontsize=fs)
def side(x,y,w,h,txt):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.06,rounding_size=0.08",fc="#f5f5f5",ec="#9a9a9a",lw=0.6))
    ax.text(x+w/2,y+h/2,txt,ha="center",va="center",fontsize=6.0,color="#444")
def arr(x1,y1,x2,y2): ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle="-|>",mutation_scale=7,lw=0.7,color="#2c5f8a"))
box(3.0,18.4,4.0,1.4,"Records identified\nEurope PMC (n=147) · PubMed (n=95)")
box(3.0,16.6,4.0,1.0,"Records after duplicates removed (n=183)"); side(7.8,18.4,3.6,0.9,"Duplicates removed (n=59)"); arr(5.0,18.4,5.0,17.6)
box(3.0,15.0,4.0,1.0,"Records screened (n=183)"); arr(5.0,16.6,5.0,16.0)
box(3.0,13.4,4.0,1.0,"Expanded corpus assessed (n=602)"); side(7.8,13.2,3.6,1.4,"Records excluded (n=451)\nnon-human 102; no archaea/CH4 163"); arr(5.0,15.0,5.0,14.4)
box(3.0,11.6,4.0,1.0,"Reports sought (n=151)"); arr(5.0,13.4,5.0,12.6)
box(3.0,10.0,4.0,1.0,"Full-text assessed (n=155)"); side(7.8,11.6,3.6,0.9,"Not retrieved (n=1)"); side(7.8,10.0,3.6,0.9,"Via reference lists (n=5)"); arr(5.0,11.6,5.0,11.0)
box(3.0,8.2,4.0,1.1,"Included in qualitative synthesis (n=155)"); arr(5.0,10.0,5.0,9.3)
box(3.0,6.2,4.0,1.3,"Included in quantitative synthesis\n(meta-analysis)\n(n=110 studies; 28,445 samples)"); arr(5.0,8.2,5.0,7.5)
lab(ax,"A")
ax2=fig.add_subplot(gs[1])
pheno=[("IGT",38),("T2D",30),("CRC",29),("Adenoma",29),("CVD",20),("IBD",8),("Hypertension",3)]
ys=list(range(len(pheno)))
ax2.barh(ys,[p[1] for p in pheno],color="#7fae8f",edgecolor="#3d6b4e",lw=0.5)
ax2.set_yticks(ys); ax2.set_yticklabels([p[0] for p in pheno]); ax2.invert_yaxis(); ax2.set_xlabel("reported methane positivity (%)")
for i,v in enumerate([p[1] for p in pheno]): ax2.text(v+0.6,i,str(v),va="center",fontsize=6.5)
lab(ax2,"B")
save(fig,"Figure 1.png")

# ================= Figure 2 : A detection, B/C attenuation, D model =================
fig=plt.figure(figsize=(W, 7.6))
gs=fig.add_gridspec(3,2, height_ratios=[1.15,1,1], hspace=0.42, wspace=0.28, left=0.08,right=0.97,top=0.95,bottom=0.07)
data=[("PRJEB10878","WGS",5.9e7,66),("PRJDB4176","WGS",4.4e7,28),("PRJNA385949","WGS",3.0e7,21),
 ("PRJEB1220","WGS",5.7e7,91),("PRJNA398089","WGS",2.3e7,10),("PRJEB53891","16S",1.8e5,100),
 ("PRJDB16834","16S",4.8e6,100),("PRJNA763023","16S",5.5e4,12),("PRJDB11845","16S",3.6e4,0)]
ax=fig.add_subplot(gs[0,0:2]); col={"WGS":"#2c5f8a","16S":"#c0392b"}
for l,t,d,det in data: ax.scatter(d,det,color=col[t],s=22,marker=("o" if t=="WGS" else "^"))
for t in ["WGS","16S"]: ax.scatter([],[],color=col[t],s=22,marker=("o" if t=="WGS" else "^"),label=t)
ax.set_xscale("log"); ax.set_xlabel("sequencing depth (median reads)"); ax.set_ylabel("archaeal detection (%)"); ax.set_ylim(-5,105); ax.legend(frameon=False); lab(ax,"A")
rows=list(csv.DictReader(open("da2_results.tsv"),delimiter="\t"))
by=defaultdict(lambda: defaultdict(list))
for r in rows: by[(r["study"],r["depth_rep"].split("_")[0])][r["grp"]].append(float(r["arch"]))
order_d=["25k","50k","100k","250k","500k"]; labs={"P10878":"China","PDB4176":"Japan"}
def gval(a,b):
    a=np.array(a); b=np.array(b)
    if len(a)<2 or len(b)<2: return (np.nan,np.nan)
    n1,n2=len(a),len(b); m1,m2=a.mean(),b.mean(); s1,s2=a.std(ddof=1),b.std(ddof=1)
    sp=math.sqrt(((n1-1)*s1*s1+(n2-1)*s2*s2)/(n1+n2-2))
    if sp==0: return (0.0,0.0)
    d=(m1-m2)/sp*(1-3/(4*(n1+n2)-9)); se=math.sqrt((n1+n2)/(n1*n2)+d*d/(2*(n1+n2))); return (d,se)
axB=fig.add_subplot(gs[1,0]); axC=fig.add_subplot(gs[1,1])
for st in ["P10878","PDB4176"]:
    xs=[];det=[];gv=[];gs_=[]
    for i,dl in enumerate(order_d):
        grp=by.get((st,dl))
        if not grp: continue
        tot=sum(len(v) for v in grp.values()); pos=sum(1 for v in grp.get("case",[]) if v>=1)+sum(1 for v in grp.get("control",[]) if v>=1)
        det.append(100*pos/tot); xs.append(i)
        d,se=gval(np.log10(np.array(grp.get("case",[0]))+1e-6), np.log10(np.array(grp.get("control",[0]))+1e-6))
        gv.append(d); gs_.append(se)
    axB.plot(xs,det,"o-",lw=1.0,ms=3.5,label=labs[st])
    axC.errorbar(xs,gv,yerr=[1.96*s for s in gs_],fmt="o-",lw=1.0,ms=3.5,capsize=2,label=labs[st])
for a,xl,yl in [(axB,"analysis depth (reads)","detection (%)"),(axC,"analysis depth (reads)","Hedges' g (CRC vs control)")]:
    a.set_xticks(range(5)); a.set_xticklabels(order_d); a.set_xlabel(xl); a.set_ylabel(yl); a.legend(frameon=False,fontsize=6.5)
axC.axhline(0,color="#999",lw=0.5,ls=":"); lab(axB,"B"); lab(axC,"C")
axD=fig.add_subplot(gs[2,0:2]); xs=np.logspace(3,9,200); p=1/(1+np.exp(-(-10.29+1.25*np.log10(xs))))
axD.plot(xs,p*100,color="#2c5f8a",lw=1.1); axD.axhline(50,color="#999",lw=0.6,ls="--")
axD.set_xscale("log"); axD.set_xlabel("sequencing depth (reads)"); axD.set_ylabel("predicted detection (%)"); axD.set_ylim(0,100); lab(axD,"D")
save(fig,"Figure 2.png")

# ================= Figure 3 : A pooled forest, B CRC, C IBD =================
fig=plt.figure(figsize=(W, 6.6))
gs=fig.add_gridspec(2,2, height_ratios=[1,1.35], hspace=0.30, wspace=0.30, left=0.30,right=0.97,top=0.95,bottom=0.09)
ax=fig.add_subplot(gs[0,0:2])
order=sorted(pool,key=lambda g:-pool[g][3]); y=0; yt=[]; yl=[]
for gg in order:
    mu,se,I2,k,es=pool[gg]; ax.plot([mu-1.96*se,mu+1.96*se],[y,y],color="#333",lw=0.9); ax.plot(mu,y,"D",color="#c0392b",ms=4)
    yt.append(y); yl.append("%s  k=%d  I²=%.0f%%"%(gg,k,I2)); y-=1
ax.axvline(0,color="#999",lw=0.6,ls="--"); ax.set_yticks(yt); ax.set_yticklabels(yl); ax.set_xlabel("Hedges' g (disease vs healthy)")
for t,l in zip(ax.get_yticklabels(),yl): t.set_fontweight("bold")
lab(ax,"A")
byd=defaultdict(list)
for s,g,n1,n2,gg,se in forest: byd[g].append((s,n1,n2,gg,se))
for key,gspec,letter in [("CRC",gs[1,0],"B"),("IBD",gs[1,1],"C")]:
    axp=fig.add_subplot(gspec); items=sorted(byd[key],key=lambda x:x[3]); y=0; yt=[]; yl=[]
    for s,n1,n2,gg,se in items:
        axp.plot([gg-1.96*se,gg+1.96*se],[y,y],color="#555",lw=0.7); axp.plot(gg,y,"o",color="#2c5f8a",ms=3)
        yt.append(y); yl.append("%s (%d/%d)"%(s,n1,n2)); y-=1
    axp.axvline(0,color="#999",lw=0.6,ls="--"); axp.set_yticks(yt); axp.set_yticklabels(yl,fontsize=6.0); axp.set_xlabel("Hedges' g")
    lab(axp,letter)
save(fig,"Figure 3.png")

# ================= Figure 4 : A WGS, B fraction, C detection, D 16S effect =================
fig=plt.figure(figsize=(W, 7.0))
gs=fig.add_gridspec(3,2, height_ratios=[1.1,1,1], hspace=0.42, wspace=0.32, left=0.42,right=0.97,top=0.95,bottom=0.08)
wr=[("PRJEB10878 CRC (China)",0.315,0.0139),("PRJDB4176 CRC (Japan)",0.158,0.0227),("PRJDB4176 Adenoma (Japan)",0.242,0.0123),
 ("FengQ_2015 CRC",0.660,0.001),("HanniganGD_2017 CRC",0.345,0.20),("WirbelJ_2018 CRC",0.051,0.84),("ZellerG_2014 CRC",0.042,0.82),
 ("MetaHIT/PRJEB1220 IBD",-0.130,0.097),("PRJNA385949 IBD",0.084,0.373)]
items=[(n,g,se_from_p(g,p)) for n,g,p in wr]+[("Pooled CRC",0.265,(0.438-0.093)/(2*1.96))]
ax=fig.add_subplot(gs[0,0:2]); forest_ax(ax,items); ax.set_xlabel("Hedges' g (archaeal fraction)"); lab(ax,"A")
# 16S data
rows=[]
for r in csv.DictReader(open("/home/admin/arch_db/16s_full_results.tsv"),delimiter="\t"):
    if r["status"]!="OK": continue
    rows.append({"grp":r["grp"],"proj":r["proj"],"tot":int(r["tot"]),"arc":int(r["arc_tot"]),"frac":float(r["arcfrac"])})
def sel(p,g): return [x for x in rows if x["proj"]==p and x["grp"]==g]
axB=fig.add_subplot(gs[1,0])
groups=[("PRJEB53891","Control"),("PRJEB53891","CRC"),("PRJNA763023","Control"),("PRJNA763023","CRC")]; xs=[0,0.7,1.9,2.6]
for x,(p,g) in zip(xs,groups):
    vals=[math.log10(v["frac"]+1e-6) for v in sel(p,g)]
    bp=axB.boxplot([vals],positions=[x],widths=0.5,showfliers=False,patch_artist=True,medianprops=dict(color="k",lw=0.8))
    bp["boxes"][0].set(facecolor=("#9ecae1" if g=="Control" else "#fc9272"),edgecolor="k",lw=0.5)
    jit=(np.random.RandomState(0).rand(len(vals))-0.5)*0.2
    axB.scatter(np.full(len(vals),x)+jit,vals,s=2.2,c=("#4292c6" if g=="Control" else "#de2d26"),alpha=0.45,linewidths=0)
axB.set_xticks(xs); axB.set_xticklabels(["Ctrl","CRC","Ctrl","CRC"],fontsize=6.5); axB.set_ylabel("log$_{10}$ archaeal fraction")
axB.text(0.35,-0.34,"P1 deep",transform=axB.transAxes,ha="center",fontsize=6.2,color="#555")
axB.text(0.80,-0.34,"P2 shallow",transform=axB.transAxes,ha="center",fontsize=6.2,color="#555"); lab(axB,"B")
axC=fig.add_subplot(gs[1,1]); xr=[x for x in rows if x["proj"]=="PRJNA763023"]; xr.sort(key=lambda x:x["tot"]); n=len(xr)
terc=[]; prev=[]
for i in range(3):
    seg=xr[i*n//3:(i+1)*n//3]; terc.append(seg[len(seg)//2]["tot"]); prev.append(sum(1 for x in seg if x["arc"]>0)/len(seg)*100)
axC.plot(range(3),prev,"o-",color="#238b45",lw=1.0,ms=3.6)
axC.set_xticks(range(3)); axC.set_xticklabels(["%.0fk"%(t/1000) for t in terc]); axC.set_xlabel("depth (median reads)"); axC.set_ylabel("detection (%)")
for i,v in enumerate(prev): axC.text(i,v+1.0,"%.1f"%v,ha="center",fontsize=6.2)
axC.set_ylim(0,max(prev)*1.5); lab(axC,"C")
axD=fig.add_subplot(gs[2,0:2]); items2=[("P1 (deep)",0.735,0.400),("P2 (shallow)",-0.055,0.062),("Pooled",0.241,0.382)]
forest_ax(axD,items2,xlabel="Hedges' g (archaeal fraction)"); axD.set_xlabel("Hedges' g (archaeal fraction)"); lab(axD,"D")
save(fig,"Figure 4.png")

# ================= Figure 5 : A DNA/RNA, B MR power =================
fig=plt.figure(figsize=(W, 3.0))
gs=fig.add_gridspec(1,2, wspace=0.32, left=0.09,right=0.97,top=0.88,bottom=0.16)
ax=fig.add_subplot(gs[0,0]); ax.bar([0,1],[1.0,2.7],color=["#9ecae1","#fc9272"],edgecolor="#333",lw=0.5)
ax.set_xticks([0,1]); ax.set_xticklabels(["DNA positive","RNA positive"]); ax.set_ylabel("HMP2 samples (%)")
for x,v in zip([0,1],[1.0,2.7]): ax.text(x,v+0.07,"%.1f%%"%v,ha="center",fontsize=6.5)
lab(ax,"A")
ax=fig.add_subplot(gs[0,1]); ORS=np.linspace(1.0,1.4,60); z=1.959964; se=(math.log(1.14))/(z+0.8416)
pw=[1-stats.norm.cdf(z-math.log(o)/se)+stats.norm.cdf(-z-math.log(o)/se) for o in ORS]
ax.plot(ORS,[p*100 for p in pw],color="#2c5f8a",lw=1.1); ax.axhline(80,color="#999",lw=0.6,ls="--"); ax.axvline(1.14,color="#999",lw=0.6,ls=":"); ax.axvline(1.06,color="#c0392b",lw=0.9)
ax.set_xlabel("true OR (per 1-SD exposure)"); ax.set_ylabel("statistical power (%)"); ax.set_ylim(0,100); lab(ax,"B")
save(fig,"Figure 5.png")

# ================= Figure 6 : A funnel, B trimfill, C DOI =================
fig=plt.figure(figsize=(W, 3.0))
gs=fig.add_gridspec(1,3, wspace=0.42, left=0.09,right=0.97,top=0.88,bottom=0.18)
es=pool["CRC"][4]; ys=np.array([e[1] for e in es]); ses=np.array([e[2] for e in es]); mu=pool["CRC"][0]
ax=fig.add_subplot(gs[0,0]); ax.scatter(ys,ses,color="#2c5f8a",s=12); ax.axvline(mu,color="#c0392b",lw=0.9)
ax.set_xlabel("Hedges' g"); ax.set_ylabel("SE"); ax.invert_yaxis(); lab(ax,"A")
ax=fig.add_subplot(gs[0,1]); ax.scatter(ys,ses,color="#888",s=12); ax.axvline(mu,color="#c0392b",lw=0.9,label="observed")
ax.axvline(trimfill["CRC"]["adj_g"],color="#2c5f8a",lw=0.9,ls="--",label="trim-fill")
ax.set_xlabel("Hedges' g"); ax.set_ylabel("SE"); ax.invert_yaxis(); ax.legend(frameon=False,fontsize=6); lab(ax,"B")
ax=fig.add_subplot(gs[0,2]); loo=[]
for i in range(len(es)):
    keep=[e for j,e in enumerate(es) if j!=i]; w=sum(1/(e[2]**2) for e in keep); loo.append((es[i][0], sum(e[1]/e[2]**2 for e in keep)/w))
loo=sorted(loo,key=lambda x:x[1])
for i,(s,m) in enumerate(loo): ax.plot(m,i,"o",color="#2c5f8a",ms=3.5)
ax.axvline(mu,color="#c0392b",lw=0.9); ax.set_yticks(range(len(loo))); ax.set_yticklabels([s for s,_ in loo],fontsize=6.0); ax.set_xlabel("pooled g (leave-one-out)"); lab(ax,"C")
save(fig,"Figure 6.png")
print("ALL COMPOSITES REBUILT")
