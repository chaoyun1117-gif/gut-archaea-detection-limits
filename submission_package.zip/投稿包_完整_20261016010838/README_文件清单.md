# 完整投稿包（图文分离 · 拼图版）
- 正文/Manuscript_EN.docx —— 正文（零图片；图以 (Figure N[面板]) 按首现顺序引用）
- 正文/Figure_Legends_EN.md —— 图题注（Figure 1..6，含 A/B/C/D 面板说明）
- 正文/Manuscript_CN.docx · 图题注_CN.md —— 中文对应件
- 图片/Figure 1.png .. Figure 6.png —— 拼图（600 dpi 无损 PNG，170 mm，1:1）
- 图片/Figure 1.pdf .. Figure 6.pdf —— 同一拼图的 PDF 矢量版（便于手动美化）
- 脚本/ —— 出图脚本（make_composites_v2.py 等，可改样式重出）
- 数据表/ · 补充材料/ · 投稿信_CoverLetter.md
面板方案：F1(A PRISMA,B 甲烷阳性率)；F2(A 检出图,B 深度衰减-检出,C 深度衰减-效应,D 检出概率模型)；F3(A 合并森林,B 组内CRC,C 组内IBD)；F4(A WGS森林,B 16S占比,C 16S检出-深度,D 16S效应)；F5(A RNA/DNA,B MR功效)；F6(A 漏斗,B trimfill,C DOI)。
