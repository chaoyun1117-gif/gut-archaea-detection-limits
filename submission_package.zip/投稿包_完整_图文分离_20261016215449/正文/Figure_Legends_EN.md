Figure 1. Study identification and the reported literature landscape. (A) PRISMA 2020 flow of study identification, screening and inclusion. (B) Reported methane positivity by phenotype in the literature line.

Figure 2. Archaeal detection is depth- and pipeline-dependent and quantitatively predictable. (A) Archaeal detection rate versus sequencing depth, population and data type. (B) Depth attenuation: detection rate versus subsampled depth. (C) Depth attenuation: CRC effect size versus subsampled depth. (D) Detection-probability model: expected archaeal detection probability versus sequencing depth (descriptive; cross-study calibration poor).

Figure 3. The archaea–disease association and its within-study robustness. (A) Pooled effect sizes of archaeal abundance across phenotypes. (B) Within-study effect sizes for CRC. (C) Within-study effect sizes for IBD.

Figure 4. Independent raw-read re-quantification. (A) Whole-genome shotgun replication effect sizes. (B) 16S archaeal fraction by project and group. (C) 16S detection versus depth. (D) 16S effect sizes.

Figure 5. Functional detection and causal bounds. (A) DNA versus RNA methanogenesis activity. (B) Mendelian-randomisation power versus effect size, with the observed point estimate.

Figure 6. Sensitivity and publication-bias diagnostics. (A) Funnel plot of the CRC meta-analysis. (B) Trim-and-fill analysis. (C) DOI (influence) plot of the CRC meta-analysis.
