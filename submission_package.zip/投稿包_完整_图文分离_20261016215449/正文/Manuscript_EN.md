# Sequencing-depth-dependent detection limits of gut methanogenic archaea and detection-driven distortion of microbiome–disease associations: a depth-aware re-appraisal of 28,445 metagenomes

Manuscript (English) — Methods and Results, SCI-standard, fully expanded · 2026-10-13

---

## Abstract

**Background.** Gut methanogenic archaea have repeatedly been associated with colorectal cancer (CRC) and inflammatory bowel disease (IBD), yet public microbiome data are optimised for bacteria, and the capacity of these data to detect low-abundance archaea has never been systematically benchmarked. Using the archaea–disease association as a case, we quantified the degree of archaeal detection failure in public faecal metagenomes and amplicon data and assessed how this failure distorts downstream association and causal inference. The question addressed here is whether these associations can be reliably observed, not whether archaea cause disease.

**Methods.** Following PRISMA 2020, three evidence lines were integrated. The literature line comprised a qualitative synthesis of 155 full texts with PICOS extraction and design-matched risk-of-bias assessment. The quantitative line was a random-effects meta-analysis of curatedMetagenomicData (110 studies; 28,445 stool samples), evaluated both across studies and within studies (case–control contrasts, batch removed by design), and complemented by functional-pathway abundance, total-load adjustment, prediction intervals and trim-and-fill. The raw-read line independently re-quantified archaea by direct alignment of 16S amplicon and whole-genome shotgun reads to archaeal references in projects carrying internal case/control labels. The core new analysis modelled archaeal detection as a function of sequencing depth, primer chemistry and population, and was complemented by a pre-specified depth-attenuation experiment, a depth-confounding counter-analysis of the disease association, and two-sample Mendelian randomisation (MR) with power analysis.

**Results.** Across studies, archaeal abundance was higher in CRC (k=10; Hedges' g=+0.30; 95% CI +0.13 to +0.47; I²=53%) and lower in IBD (k=6; g=−0.32; 95% CI −0.59 to −0.05; I²=87%); within-study contrasts were concordant (CRC g=+0.358; 95% CI +0.16 to +0.56; IBD g=−0.342; 95% CI −0.63 to −0.06). The methanogenesis pathway METHANOGENESIS-PWY was enriched 3.80-fold in CRC and reduced to 0.34-fold in IBD, and adjustment for sequencing depth left the estimates essentially unchanged. Detection, however, was strongly technical: it rose monotonically with sequencing depth (a Chinese CRC cohort, 31%→73% from 2.5×10⁴ to 5×10⁵ reads; effect size g +0.190→+0.315), one bacterial-primer dataset yielded 0% archaeal detection, and apparent population differences in detection were not separable from study-level technical factors. Controlling for depth, the CRC and IBD associations were essentially unchanged (CRC +0.407→+0.408; IBD −0.408→−0.394). Re-quantification of the same samples with a different pipeline (cross-pipeline consistency) reproduced the CRC association in the two deeply sequenced cohorts (China g=+0.315, p=0.0139; Japan g=+0.158, p=0.0227), and the pooled contrast was g=+0.265 (95% CI +0.093 to +0.438); because these datasets overlap with the quantitative line (Supplementary Table S1), they provide cross-pipeline consistency rather than external validation. Two-sample MR was null (CRC OR=1.06; IBD OR=1.04) but had only ~0.23 power at the observed effect (minimum detectable OR≈1.14).

**Conclusions.** Public data show systematic detection limitation for low-abundance archaea, and "not detected" is commonly misread as "absent". The archaea–disease association is directionally consistent but may be weakened or altered by technical bias. Detection was strongly depth-dependent and poorly calibrated across studies, so detection rate, assay sensitivity and adequacy must not be conflated and no universal minimum depth can be recommended; a validated minimum detectable-abundance standard remains to be established.

**Keywords.** gut archaea; methanogens; detection limit; sequencing depth; primer bias; meta-analysis; colorectal cancer; inflammatory bowel disease

---

## 1. Introduction

Gut methanogenic archaea, dominated by *Methanobrevibacter smithii* [1], catalyse the terminal step of colonic fermentation, reducing H₂/CO₂, formate or methylated substrates to methane and thereby lowering the hydrogen partial pressure (pH₂) that otherwise limits the re-oxidation of NADH during fermentation [2]. Because this hydrogen sink is coupled to the interconversion of acetate, propionate, butyrate, formate and bile acids, methanogens occupy a metabolic hub that links microbial energetics to host energy harvest and to mucosal redox state [2,3]. Reported disease associations are directionally divergent: archaeal abundance tends to be higher in colorectal cancer (CRC) [4-6] and lower in inflammatory bowel disease (IBD) [6,7]. The CRC-side excess is compatible with redirected hydrogen and sulfur metabolism in the tumour microenvironment, whereas the IBD-side deficit is compatible with competitive sulfate reduction together with the elevated mucosal oxygen and nitrate that accompany inflammation; the two phenotypes also show the opposing clinical behaviour of methanogens and hydrogen-sulfide producers [3].

Clinically, methanogen load is not a passive covariate: methane is used as a diagnostic and therapeutic target through breath testing and the intestinal-methanogen-overgrowth (IMO) framework [8,9]. Yet this clinical signal rests on measurements taken at very different depths of resolution — breath gas, targeted quantitative PCR, and untargeted shotgun sequencing — whose mutual agreement has rarely been quantified.

A largely unexamined premise is that public microbiome data render all microbial taxa "unbiasedly visible". In practice, both mainstream taxonomic classifiers and amplicon primer systems are optimised around bacterial reference sequences and bacterial 16S rRNA gene coverage, and their sensitivity to low-abundance, primer-mismatched archaea has never been systematically benchmarked [10,11]. The consequences run in two directions. First, a negative result may reflect detection failure rather than biological absence. Second, because relative-abundance estimates are compositional [12] and depend on an implicit detection floor, cross-population and cross-platform differences in detectability can silently confound association and causal inference — the same biological signal may be measurable in one dataset and invisible in another. These problems are amplified by standard analytic choices: count normalisation and rarefaction change both the sensitivity and the specificity of downstream tests [13,14], and relative-abundance profiling is sensitive to the microbial load that normalisation discards [15].

Low-abundance taxa in general sit near the detection edge of both shotgun and amplicon data, so that "not detected" is routinely written as "absent" [14,15]. Gut archaea are an unusually informative probe of this problem: their abundance is low, their 16S rRNA genes are poorly matched by bacterial-type primers [10,11], and their disease associations have been reported both as positive and as negative — the heterogeneity one expects when a weak biological signal is measured near the limit of detection.

Using the archaea–CRC/IBD association as a case, this study tests a single proposition with three parts: public faecal metagenomic and amplicon data exhibit systematic detection failure for gut archaea; the failure follows a quantifiable gradient across sequencing depth, primer chemistry and population; and it distorts downstream statistical inference in a direction that can be predicted from how well the taxon is detected. The archaea–disease association therefore serves both as an object of study and as a diagnostic probe that exposes the detection failure. The question is whether the association can be reliably observed, not whether archaea are pathogenic.

**Inheritance and increment.** This study inherits a conceptual position established in the study of rumen methanogenesis under chronic low oxygen: that methanogens are terminal hydrogen sinks whose apparent abundance is a joint property of the environment and of the measurement, so that "how much methanogenic capacity is present" and "how much of it is *visible*" are not the same question. The hydrogen-partial-pressure framing, the coupling of methanogenesis to fermentation end-products and to mucosal redox state, and the use of a natural extreme system to expose otherwise hidden constraints are carried over here to a different system — the human colon viewed through public sequence data. The increment is quantitative and methodological rather than conceptual: we do not propose a new archaea–disease mechanism, but a *detection-limited* re-appraisal of existing human metagenomes, formalising a minimum detectable abundance, a depth-dependent detection gradient, and a detection-versus-abundance decomposition that can reverse the sign of a reported association.

---

## 2. Materials and Methods

### 2.1 Study design and reporting
The study integrated three complementary evidence lines. The **literature line** synthesised published human studies. The **quantitative line** re-analysed a large standardised public resource. The **raw-read line** independently re-quantified archaea from primary sequencing reads. The work was reported following the PRISMA 2020 statement, with the flow of identification, screening, eligibility and inclusion summarised in Figure 1A. The literature line (155 full texts) and the quantitative line (110 studies; 28,445 stool samples from curatedMetagenomicData) are independent evidence lines; the quantitative line is not derived from the 155 full texts. Because only public secondary data were used and no participants were enrolled, prospective registration was not applicable.

### 2.2 Information sources and search strategy
PubMed, Europe PMC and Web of Science were searched without language restriction. Search strings combined a host/disease axis (colorectal cancer, colon cancer, adenoma, inflammatory bowel disease, Crohn disease, ulcerative colitis, gut microbiome, gut metagenome) with an archaea axis (methanogen, archaea, *Methanobrevibacter*, *Methanosphaera*, methane, methanogenesis). Records were de-duplicated across databases, and the reference lists of included reviews were screened for additional primary studies.

### 2.3 Eligibility criteria
Studies were eligible if they reported human gut (stool or colonic) archaeal or methanogenic measurement—taxonomic abundance, methane production, or methanogenesis-related genes and pathways—within a design allowing a case-versus-non-case comparison. Animal-only studies, non-gut specimens, studies with no archaeal or methane measurement, and narrative reviews without primary data were excluded; reviews were retained only as background.

### 2.4 Screening, relevance grading and data extraction
Titles, abstracts and full texts were screened in sequence and graded into four relevance strata: closely related (72), related (37), contextual (42) and irrelevant (4). Disagreements and ambiguities were resolved in two recorded rounds. PICOS data were extracted into a primary table containing 86 rows, with complete sample-size coverage (86/86; 82 numeric). Each extracted value was accompanied by the supporting source sentence and page so that it could be independently verified; where a numeric value could not be traced to a source sentence, it was downgraded to a qualitative statement rather than estimated.

### 2.5 Sample-level provenance and labelling
Because aggregate project-to-disease labels derived from public repositories can be unreliable, a sample-level provenance table was constructed with nine columns: run accession, project, sample accession, original disease text, classification, source field, source URL, verification level and adoption flag. Labels were accepted only from sample-level fields (sample title, BioSample attribute, or a curated sample-level condition). Samples lacking an explicit disease field were recorded as **unusable** rather than inferred, and each adopted label carried a resolvable accession URL. This procedure was adopted after an earlier project-level label was found to be incorrect, and it was applied uniformly across all raw-read datasets.

### 2.6 Risk of bias and certainty of evidence
Risk of bias was assessed with tools matched to study design: RoB2 for randomised trials (7), ROBINS-E for non-randomised cohort studies (53) and QUADAS-2 for diagnostic-accuracy studies (8); case reports (3) were appraised descriptively using CARE reporting items, which are a reporting guideline and not a risk-of-bias instrument, and were not counted in the risk-of-bias denominator, together with a structured appraisal of one review. Domain-level sheets and a GRADE-style summary were maintained. The most frequently unmet domains were the absence of a negative control, the absence of batch correction and the absence of absolute quantification.

### 2.7 Quantitative data source
The quantitative line used stool samples from curatedMetagenomicData version 3.0, comprising 28,445 samples across 110 studies and standardised to relative abundance (MetaPhlAn taxonomic profiles). Archaeal abundance, including the genera *Methanobrevibacter*, *Methanosphaera*, *Methanomassiliicoccus* and *Methanobacterium*, was compiled with per-sample disease matching. Only samples carrying a valid disease label and an abundance value entered the analysis.

### 2.8 Effect-size estimation and pooling
Effect sizes were Hedges' g computed on log₁₀-transformed relative abundance, log₁₀(x + 1×10⁻⁶), a transformation chosen to accommodate the strong zero-inflation and right-skew of archaeal abundance. Study-level effects were pooled with DerSimonian–Laird random effects, and we report the pooled estimate with a 95% confidence interval, the between-study variance τ², Cochran's Q, the I² statistic and a random-effects prediction interval. For phenotypes represented by three or fewer studies, a pooled point estimate was deliberately not reported, and only the direction and heterogeneity were described.

### 2.9 Within-study (batch-controlled) contrasts
To remove between-project batch effects by design rather than by post-hoc correction, case-versus-control contrasts were computed only within studies containing both groups internally, with each study contributing exactly one contrast and a minimum of five samples per group; contrasts were then pooled across studies by random effects. Because every contrast originates from a single sequencing batch and pipeline, this design cannot be confounded by inter-project technical variation.

### 2.10 Functional-pathway analysis
Relative abundance of the methanogenesis pathway METHANOGENESIS-PWY was extracted from HUMAnN pathway abundance within curatedMetagenomicData (9 studies; 2,929 samples) and compared within studies (CRC versus healthy; IBD versus healthy). This analysis tests whether taxonomic changes are accompanied by functional changes and thereby addresses compositional-closure confounding.

### 2.11 Sequencing-depth adjustment (sensitivity)
As a single sensitivity module, `number_reads` was used as a sequencing-depth covariate (reads per sample) and was not interpreted as a measure of microbial load; pooled estimates were recomputed with it. A within-study depth-adjusted variant of the same adjustment is reported in Section 2.15. The two are variants of one adjustment (primary estimate and sensitivity), not two independent lines of evidence.

### 2.12 Publication bias and sensitivity analyses
Funnel plots and Egger's regression were used to screen for small-study effects, and trim-and-fill estimated the number of potentially missing studies. Leave-one-out analysis, a DOI (influence) plot and triangulation across the literature, quantitative and raw-read layers were used to probe robustness. The Egger asymmetry was not interpreted as evidence of publication bias where trim-and-fill imputed no missing studies.

### 2.13 Detection-probability modelling
Archaeal detection was defined as the presence of at least one archaeal read (or an archaeal relative abundance above the pipeline detection floor) in a sample, and the detection rate was defined as the proportion of detected samples. Detection rate was modelled across datasets as a function of sequencing depth (log₁₀ reads), primer chemistry and data type (bacterial-type 16S, archaea-compatible 16S, or whole-genome shotgun) and population. At the sample level, a logistic model was fitted across all stool samples (n=26,731) with detection as the dependent variable and log₁₀(number_reads) and population (Asia versus Europe/US) as predictors, and the independent contribution of each factor was expressed as an odds ratio.

### 2.14 Depth-attenuation experiment
Two deeply sequenced CRC cohorts (PRJEB10878; PRJDB4176) were subsampled to 2.5×10⁴, 5×10⁴, 1×10⁵ and 2.5×10⁵ reads per sample by truncating the read stream, alongside the full 5×10⁵-read analysis. At each depth, archaeal reads were counted with the identical alignment pipeline, and both the detection rate and the CRC-versus-control effect size (Hedges' g) were computed. The experiment was pre-specified to test the prediction that shallow sequencing attenuates both detection and effect size.

### 2.15 Depth-confounding adjustment of the disease association
To exclude the possibility that the disease association is itself an artefact of case–control depth imbalance, within each study log₁₀(archaeal abundance) was regressed on group plus log₁₀(number_reads); the group coefficient was pooled across studies by inverse-variance weighting and compared with the unadjusted group coefficient.

### 2.16 Independent raw-read re-quantification
**16S amplicon line.** A dual-domain 16S reference was constructed from RefSeq Targeted Loci, comprising 26,876 bacterial and 1,160 archaeal sequences (214 of which were methanogens), with domain- and genus-level tags embedded in the sequence headers. Reads were aligned with bowtie2 to an archaea-only reference, and the archaeal fraction was defined as archaeal aligned reads divided by total reads. Projects carrying internal case/control labels were analysed (PRJEB53891, PRJNA763023, PRJDB16834 and PRJDB11845); for PRJEB53891 the pre-surgery samples were used to avoid repeated-measures bias. The measured read length was 250 bp.

**Whole-genome shotgun line.** A bowtie2 index was built from three gut methanogen genomes (*M. smithii*, *M. stadtmanae*, *M. luminyensis*) and validated with a synthetic-read positive control that aligned at 100%. Because the reference contains only these three dominant gut methanogens, all whole-genome shotgun results refer specifically to gut methanogens and not to the archaeal domain as a whole. The first 5×10⁵ reads of read 1 of each sample were used. Projects carrying internal labels were analysed (PRJEB10878, PRJDB4176, PRJNA385949, PRJEB1220, PRJNA398089, PRJEB12449 and PRJNA422434); CRC contrasts were additionally pooled by random effects, and IBD was aggregated at the subject level to avoid pseudo-replication.

### 2.17 Mendelian randomisation and power
Instrument variables were drawn from the MiBioGen genome-wide association study for the genus *Methanobrevibacter* at a threshold of P<1×10⁻⁵ and pruned for linkage disequilibrium at 10 Mb, yielding eight independent instruments (mean F=21). Outcomes were FinnGen release 11 CRC (C3_COLORECTAL_EXALLC) and IBD (K11_IBD_STRICT). The primary estimator was inverse-variance weighting, with MR-Egger intercept and Cochran's Q as sensitivity analyses. The odds ratio corresponds to a one-standard-deviation higher genetically predicted *Methanobrevibacter* abundance. Statistical power was characterised by the standard error of the log odds ratio, the minimum detectable odds ratio at 80% power, and the power at the observed effect. Because of the power limitation, this analysis is reported in the Supplementary Material and is used only to bound the causal effect, not to test the detection-limitation mechanism.

### 2.18 Sequencing depth definitions, read accounting and quality
Three depth quantities were distinguished and reported separately. (i) **Library depth**: the number of raw reads per sample deposited for the study (raw, paired-end counted as read pairs). (ii) **Effective depth**: the number of reads remaining after quality control and host removal. (iii) **Analysis depth**: the number of reads that actually entered the archaea-detection alignment. In the whole-genome shotgun line a fixed analysis depth of 5×10⁵ read-1 reads per sample was used; therefore the dataset-level detection rates (Table 1) and the detection map (Figure 2A) describe detection at this fixed analysis depth and must not be read as detection at the full library depth. Library depth (e.g., 3–7×10⁷ reads) and analysis depth (5×10⁵ reads) differ by two orders of magnitude and are reported separately throughout. Random subsampling was used to vary the analysis depth (Section 2.14). For the 16S line, per-sample total reads and the 16S mapping fraction were recorded. No quantitative PCR or internal standard was available, so all estimates are relative abundance rather than absolute load, and no per-sample microbial-load measurement was available; a compositional (relative-abundance) influence therefore cannot be formally excluded.

For every dataset analysed in the raw-read line we recorded library strategy, sequencing platform and per-sample read count, and treated depth explicitly as a covariate where it differed between groups. For the 16S line, per-sample total reads and the 16S mapping fraction were recorded; for the whole-genome shotgun line, per-sample read counts were recorded. No quantitative PCR or internal standard was available, so all estimates are relative abundance rather than absolute load.

### 2.19 Software and reproducibility
Analyses used Python 3.12 (numpy, scipy), bowtie2 and samtools. Meta-analysis used a self-implemented DerSimonian–Laird estimator, and regression used ordinary least squares and logistic models. All scripts, input manifests and intermediate result tables were persisted so that every reported number can be recomputed.

---

### 2.20 Detection specificity and sensitivity validation
The archaeal reference comprised 135 contigs from three gut archaeal species (Methanosphaera stadtmanae, 108 contigs; Methanomassiliicoccus luminyensis, 26; Methanobrevibacter smithii, 1); all results are therefore limited to these three targets. Reads were aligned with bowtie2 (end-to-end, default settings); a read was counted positive if it had at least one valid alignment, with one primary alignment per read. Positivity was defined as >=1 read, and threshold sensitivity was assessed at >=2, >=5, >=10 and >=20 reads. Three controls were run: (i) negative control, 400,000 simulated 150-bp reads from ten gut bacterial genomes (Escherichia coli, Bacteroides fragilis, Bacteroides thetaiotaomicron, Phocaeicola vulgatus, Bifidobacterium longum, Bifidobacterium breve, Ligilactobacillus salivarius, Akkermansia muciniphila, Agathobacter rectalis, Staphylococcus aureus) aligned to the archaeal index, counting false-positive reads; (ii) positive control, 400,000 simulated archaeal reads aligned back to the index; and (iii) spike-in recovery, in which archaeal reads were mixed into a bacterial background at 0.01%, 0.1% and 1% of reads at analysis depths of 25,000, 100,000 and 500,000 reads, five replicates each. Competitive alignment of real reads against a combined archaeal+bacterial index tested for cross-mapping. Simulated reads do not reproduce real DNA extraction, PCR or library preparation and therefore provide an upper bound on recovery.

### 2.21 Study-level detection model
A sample-level detection model was fitted on the 26,731 stool metagenomes with finite read counts (26.1% detected) by conditional logistic regression: detected ~ log10(reads) + study fixed effects, with study entered as a fixed effect to absorb all study-level technical variation. Nonlinearity was assessed by adding a quadratic term (log10 reads squared) and tested by likelihood ratio. Cohort influence was assessed by leave-one-study-out refitting. Region (six categories), sequencing platform and DNA-extraction method were examined as separate one-covariate models because they are nested within study and cannot be entered together with study fixed effects (76/79 studies used a single platform and 56/79 a single extraction method, producing collinearity).

### 2.22 Robustness of the disease association to depth adjustment
Unadjusted and adjusted models used the same sample set. Because archaeal relative abundance was zero in 76% of CRC and 88% of IBD samples, effects were assessed on the arcsine-square-root scale with pseudocounts of 1e-6, 1e-5, 1e-4, 1e-3 and 1e-2, and a two-part model separated detection (logistic regression with study fixed effects) from abundance among positive samples (Hedges g). Abundance results are conditional on detection and do not represent all samples.

### 2.23 Meta-analysis robustness
Random-effects meta-analysis used REML estimation with Hartung-Knapp-Sidik-Jonkman inference, and prediction intervals were reported to distinguish the mean association from the effect expected in a new cohort. IBD heterogeneity was examined by leave-one-study-out. Phenotypes with k<4 were not pooled; their single-study results are reported descriptively in the Supplementary Material, so that one rule for small k is applied consistently across Methods and Results.

### 2.24 Ground-truth and detection-limit validation
Two public ground-truth resources were used. (i) The MBARC-26 mock community (23 bacterial and 3 archaeal strains, real DNA extraction, library preparation and sequencing) was re-analysed with the same archaeal pipeline used in the raw-read line, against a reference built from the three MBARC archaeal genomes and 22 of its bacterial genomes; the whole-genome and 16S V3-V4 archaeal fractions were compared. (ii) A minimum-detectable-abundance (MDA) experiment spiked simulated reads from the gut methanogen Methanobrevibacter smithii (NC_009515.1) into the real MBARC bacterial background at 0.001%, 0.01%, 0.1% and 1% of reads at analysis depths of 25,000, 100,000, 500,000 and 1,000,000 reads, five replicates each, aligned to a combined archaeal+bacterial index. Because the spiked reads were generated in silico and the MBARC archaea are haloarchaea rather than gut methanogens, these results validate pipeline accuracy and give an upper bound on sensitivity rather than a stool-specific truth.

### 2.25 Detection-fragility scan of published associations
Genus-level MetaPhlAn3 relative abundances for 15 case–control studies were obtained from curatedMetagenomicData (281 genera; 4,355 samples) and analysed per genus for CRC and IBD. For each genus the case–control contrast was computed on the full relative-abundance scale (the usual published analysis), as detection (prevalence, Fisher exact), and as abundance among detected samples (a two-part model). Genera whose association was carried by prevalence rather than by abundance among detected samples were flagged as detection-fragile.

## 3. Results
### 3.1 Detection specificity and sensitivity
Alignment of 400,000 bacterial-background reads to the archaeal index yielded 0 positive reads (false-positive rate 0.00%), whereas 400,000 archaeal reads were recovered at 100.0%. In the spike-in experiment, detection was 100% at every spike level and depth tested, and the mean number of detected reads closely matched the number spiked in (for example, 50 detected versus 50 expected for a 0.01% spike at 500,000 reads), indicating quantitative recovery. Detection rate was strongly threshold-dependent: at 500,000 reads it was 41% at >=1 read, 20% at >=2 reads, 15% at >=5 reads, and 15% at both >=10 and >=20 reads, so the positivity rule must be stated explicitly and detection rate, sensitivity and adequacy must not be conflated. Competitive alignment of 500,000 real reads from a CRC sample produced 91 archaeal and 63,188 bacterial alignments, indicating negligible cross-mapping; approximately half of the archaeal hits in that single competitive run had low mapping quality. To test whether the quantification depends on such alignments, archaeal alignments from 20 deeply sequenced PRJEB10878 samples (10 CRC, 10 control; 500,000 reads each) were binned by mapping quality: 95.3% of archaeal reads had MAPQ ≥ 20 and only 4.6% had MAPQ < 10. Restricting to MAPQ ≥ 20 left the case–control contrast essentially unchanged (mean archaeal reads per 500,000: CRC 3,730 vs control 59; CRC-to-control ratio 63.0 versus 62.3 unfiltered), so the read-level signal is carried by high-quality alignments rather than by low-mapping-quality reads.

### 3.2 Study-level detection model
With study fixed effects, the odds of detection increased by an estimated factor of 2.07 per log10 increase in reads (coefficient +0.726, p=1.3e-18, pseudo-R2=0.177). The depth relationship was significantly nonlinear (quadratic term p=0.0004; concave), so a purely linear logit was not adequate. The depth coefficient was stable under leave-one-study-out refitting (range 0.654-0.874; median 0.726), indicating that it was not driven by any single cohort. Region was strongly associated with detection when modelled alone (Asia OR=0.25, p=6e-68), but after adjusting for study the regional estimates changed markedly and the Asia estimate was no longer significant (OR=0.35, p=0.24); because 72/79 studies were single-region, region is not separable from study and technical factors, and all regional findings are therefore reported as exploratory associations only, not as population net effects (Table 2). Sequencing platform (e.g., MiSeq OR=0.09, NovaSeq OR=1.71 vs HiSeq) and DNA-extraction method (ORs spanning 0.05 to 17) were also strongly associated with detection, but these are likewise confounded with study. The curatedMetagenomicData layer is whole-genome shotgun (MetaPhlAn); 16S data were analysed separately in the raw-read line.

### 3.3 Detection is strongly associated with technical factors; no disease-group association was found
Archaeal detection rate varied greatly across datasets—from 21% (Hall, USA) to 91% (MetaHIT, Europe) among whole-genome datasets, and from 12% to 100% among 16S datasets (Table 1; Figure 2A). Two technical determinants were evident. First, sequencing depth: deeply sequenced 16S datasets reached 100% detection whereas shallow 16S datasets fell to 12%, and a large shallow cohort showed a monotonic increase across depth tertiles (4.9%, 11.3% and 20.8%); in logistic regression of detection on group plus log₁₀(depth), the depth coefficient was +2.79 (p<0.001) whereas the group coefficient was not significant (odds ratio 0.91; p=0.62). Detection was therefore strongly associated with sequencing depth, and no significant association with disease group was detected. Second, primer chemistry: one 16S dataset (PRJDB11845) showed zero archaeal detection although approximately 95% of its reads aligned to bacterial 16S, indicating that bacterial-type primers cannot amplify archaea.

**Table 1. Sequencing depth, platform and observed archaeal detection for the raw-read datasets.**

| Dataset | Data type | Platform | Median reads/sample | Detection |
| --- | --- | --- | --- | --- |
| PRJEB10878 | WGS | Illumina NovaSeq | 5.9×10⁷ | 66% |
| PRJDB4176 | WGS | Illumina | 4.4×10⁷ | 28% |
| PRJNA385949 | WGS | Illumina | 3.0×10⁷ | 21% |
| PRJEB1220 | WGS | Illumina | 5.7×10⁷ | 91% |
| PRJNA398089 | WGS | Illumina | 2.3×10⁷ | 5–14% |
| PRJEB53891 | 16S | NovaSeq/NextSeq | 1.8×10⁵ | 100% |
| PRJDB16834 | 16S | Ion Torrent S5 | 4.8×10⁶ | 100% |
| PRJNA763023 | 16S | NovaSeq | 5.5×10⁴ | 12% |
| PRJDB11845 | 16S | MiSeq PE | 3.6×10⁴ | 0% |



### 3.4 Depth attenuation of detection and effect size
To test directly whether shallow sequencing attenuates the archaeal signal, the two deeply sequenced CRC cohorts were subsampled to progressively shallower depths. In the Chinese cohort, both detection and effect size rose monotonically with depth: detection increased from 31% to 73% and the effect size from +0.190 to +0.315 as depth increased from 2.5×10⁴ to 5×10⁵ reads. In the Japanese cohort, detection rose monotonically from 10% to 29.5% and the effect size increased overall from +0.078 to +0.158, although it was less regular at intermediate depths. Shallow sequencing therefore attenuated both detection and the measured effect size (Figure 2B,C).


### 3.5 Literature and risk-of-bias characteristics
The literature line assessed 155 full texts; of these, 72 closely related studies formed the risk-of-bias set. Of the 155, 72 were closely related, 37 related, 42 contextual and 4 irrelevant. The PICOS primary table contained 86 rows with complete sample-size coverage, and risk-of-bias assessment covered the 72 closely related studies with the tools RoB2 (7), ROBINS-E (53), QUADAS-2 (8), CARE (3) and review appraisal (1). Within the literature line, reported methane positivity was heterogeneous across diseases: it was highest in impaired glucose tolerance (38%) and in type 2 diabetes (30%), intermediate and similar in CRC and adenoma (29%) and in cardiovascular disease (20%), and lowest in IBD (8%) and hypertension (3%) (Table 3; Figure 1B). This descriptive heterogeneity established that the reported visibility of methanogens varies substantially by phenotype and by study, motivating the quantitative and detection-focused analyses below.

**Table 3. Methane positivity by phenotype in the literature line.**

| Phenotype | Reported methane positivity |
| --- | --- |
| Impaired glucose tolerance | 38% |
| Type 2 diabetes | 30% |
| CRC | 29% |
| Adenoma | 29% |
| Cardiovascular disease | 20% |
| IBD | 8% |
| Hypertension | 3% |




### 3.6 The archaeal association is robust and direction-specific
In the quantitative line, across-study random-effects meta-analysis showed that archaeal relative abundance was higher in CRC (k=10; Hedges' g=+0.30; 95% CI +0.13 to +0.47; I²=53%) and lower in IBD (k=6; g=−0.32; 95% CI −0.59 to −0.05; I²=87%) (Table 4; Figure 3A). The same pattern was observed when only within-study case–control contrasts were pooled (CRC g=+0.358; 95% CI +0.16 to +0.56; I²=67%; IBD g=−0.342; 95% CI −0.63 to −0.06; I²=90%), indicating that the association is not an artefact of between-project batch differences (Figure 3B,C). For phenotypes represented by few studies, the direction was not consistent (adenoma g=+0.156; type 2 diabetes g=+0.03; impaired glucose tolerance and hypertension were not pooled), and these phenotypes were treated descriptively.

**Table 4. Pooled association between archaeal abundance and disease (random-effects meta-analysis).**

| Phenotype | Studies (k) | Hedges' g (95% CI) | I² | Prediction interval |
| --- | --- | --- | --- | --- |
| CRC | 10 | +0.30 (+0.13 to +0.47) | 53% | −0.19 to +0.79 |
| IBD | 6 | −0.32 (−0.59 to −0.05) | 87% | −1.21 to +0.56 |
| Adenoma | 4 | +0.156 (+0.006 to +0.31) | 0% | −0.23 to +0.46 |
| Type 2 diabetes | 10 | +0.03 | 84% | −0.94 to +1.00 |
| Impaired glucose tolerance | 3 | not pooled‡ | 95% | −8.1 to +8.3 |
| Hypertension | 2 | not pooled‡ | — | −0.17 to +0.29 |

‡ Point estimates were not pooled for phenotypes with three or fewer studies; only direction and heterogeneity are described.




### 3.7 Within-study contrasts confirm the association
Per-study within-study contrasts are given for CRC (Table 5), IBD (Table 6) and the remaining phenotypes (Table 7). For CRC, eight of ten studies had a positive effect, and the two largest effects were in FengQ_2015 (g=+0.82) and GuptaA_2019 (g=+0.94); the largest study, YachidaS_2019 (516 cases and 502 controls), had a small positive effect (g=+0.09). For IBD, the direction was negative in four of five studies, with the strongest effect in IjazUZ_2017 (g=−0.98) and a consistent negative effect in the largest study, HMP_2019_ibdmdb (2402 cases and 852 controls; g=−0.35). The direction of the within-study estimates therefore matched the across-study meta-analysis.

**Table 5. Within-study archaeal abundance contrast in CRC (pooled g=+0.358; 95% CI +0.16, +0.56; I²=67%; τ²=0.060).**

| Study | Cases | Controls | g (SE) | Detection, cases vs controls |
| --- | --- | --- | --- | --- |
| FengQ_2015 | 46 | 61 | +0.82 (0.20) | 71.7% vs 27.9% |
| GuptaA_2019 | 30 | 30 | +0.94 (0.27) | 56.7% vs 16.7% |
| HanniganGD_2017 | 27 | 28 | +0.21 (0.27) | 33.3% vs 25.0% |
| ThomasAM_2018b | 32 | 28 | +0.85 (0.27) | 68.8% vs 32.1% |
| ThomasAM_2019_c | 40 | 40 | +0.46 (0.23) | 22.5% vs 7.5% |
| VogtmannE_2016 | 52 | 52 | +0.04 (0.20) | 46.2% vs 42.3% |
| WirbelJ_2018 | 60 | 65 | +0.17 (0.18) | 50.0% vs 40.0% |
| YachidaS_2019 | 516 | 502 | +0.09 (0.06) | 12.0% vs 10.0% |
| YuJ_2015 | 74 | 54 | +0.24 (0.18) | 31.1% vs 18.5% |
| ZellerG_2014 | 53 | 61 | +0.20 (0.19) | 69.8% vs 60.7% |

**Table 6. Within-study archaeal abundance contrast in IBD (pooled g=−0.342; 95% CI −0.63, −0.06; I²=90%; τ²=0.086).**

| Study | Cases | Controls | g (SE) | Detection, cases vs controls |
| --- | --- | --- | --- | --- |
| HMP_2019_ibdmdb | 2402 | 852 | −0.35 (0.04) | 4.6% vs 14.3% |
| HallAB_2017 | 370 | 148 | +0.12 (0.10) | 3.2% vs 1.4% |
| IjazUZ_2017 | 112 | 76 | −0.98 (0.16) | 7.1% vs 42.1% |
| LiJ_2014 | 140 | 10 | −0.24 (0.33) | 28.6% vs 40.0% |
| NielsenHB_2014 | 148 | 248 | −0.30 (0.10) | 29.7% vs 46.0% |

**Table 7. Within-study archaeal abundance contrast in other phenotypes.**

| Phenotype | Studies (k) | g (95% CI) | I² | τ² |
| --- | --- | --- | --- | --- |
| Adenoma | 4 | +0.156 (+0.006 to +0.31) | 0% | 0 |
| Type 2 diabetes | 6 | +0.151 (−0.18 to +0.48) | 88% | 0.119 |
| Impaired glucose tolerance | 3 | not pooled‡ | 94% | 0.233 |

### 3.8 The disease association is essentially unchanged after depth adjustment
To exclude the possibility that the disease association is itself an artefact of case–control depth imbalance, the within-study group effect was recomputed with depth as a covariate. The pooled effect was essentially unchanged: CRC +0.407 to +0.408 and IBD −0.408 to −0.394, a change of less than 4%, with direction and significance preserved (Table 8). Under the models used, the association estimates were essentially unchanged after depth adjustment.

**Table 8. Pooled within-study disease association before and after depth adjustment.**

| Phenotype | Unadjusted β_group (SE) | Depth-adjusted β_group (SE) | Change |
| --- | --- | --- | --- |
| CRC (k=10) | +0.407 (0.100) | +0.408 (0.100) | +0.2% |
| IBD (k=5) | −0.408 (0.051) | −0.394 (0.051) | −3.4% |

### 3.9 Robustness of the CRC and IBD associations
The CRC and IBD effects were insensitive to the pseudocount (CRC g 0.169-0.168; IBD -0.374 to -0.367 across 1e-6 to 1e-2). In the two-part model, CRC showed both higher detection (odds ratio 1.71, p=2.7e-6) and higher abundance among detected samples (g=0.100), whereas IBD showed lower detection (odds ratio 0.37, p=2.6e-21) but slightly higher abundance among detected samples (g=0.165). The IBD signal is therefore driven by lower detection (prevalence) rather than by lower abundance among detected samples, and may itself be a detection effect.

### 3.10 Meta-analysis robustness
Under REML with HKSJ inference, the pooled CRC effect was g=0.238 (HKSJ SE 0.086; tau2=0.000; prediction interval +0.03 to +0.45, not crossing zero; leave-one-out range +0.197 to +0.275). The pooled IBD effect was g=-0.312 (HKSJ SE 0.143; tau2=0.046; prediction interval -1.03 to +0.41, crossing zero; leave-one-out range -0.407 to -0.188). The CRC association was robust to the meta-analytic method, whereas the IBD association was not, and the IBD effect did not clearly persist into a new cohort.

### 3.11 Functional coherence of the association
At the functional level, the relative abundance of METHANOGENESIS-PWY (9 studies; 2,929 samples) was 22.9% in CRC versus 8.8% in healthy controls, a 3.80-fold increase, and 1.0% in IBD versus 8.8% in healthy controls, a reduction to 0.34-fold. Because the direction of the functional change matched the direction of the taxonomic change, the association cannot be explained solely by a compositional shift in relative abundance without a corresponding change in methanogenic capacity.

### 3.12 Detection-probability prediction model
In the study-level model (n=26,731; Section 3.2), detection rose with depth (odds ratio 2.07 per log10 increase in reads; p=1.3e-18) and the relationship was nonlinear. When this model was validated across studies by leave-one-study-out, its calibration was poor (calibration slope 0.44, intercept −0.59), so it is used only as a within-study descriptive predictor of detection probability and not as a universal adequacy criterion; no minimum sufficient depth is proposed. Figure 2D shows the fitted detection probability against depth. Detection rate, assay sensitivity and adequacy are distinct quantities and are used with these specific meanings throughout; regional terms were removed because region is not separable from study (Section 3.2).

**Table 2. Unadjusted sample-level logistic model of archaeal detection (dependent variable: detected; n=26,731). Region is entered as a covariate but is confounded with study and is shown for completeness only, not as a population net effect.**

| Predictor | β (SE) | OR | p |
| --- | --- | --- | --- |
| Intercept | −10.29 (0.37) | — | <0.001 |
| log₁₀(reads) | +1.25 (0.05) | 3.50 | <0.001 |
| Asia (vs Europe/US) | −1.29 (0.05) | 0.28 | <0.001 |


### 3.13 Raw-read re-quantification — whole-genome shotgun (cross-pipeline consistency)
Within-project whole-genome shotgun results (gut methanogens) are given in Table 9. The two deeply sequenced Asian CRC cohorts were significant (PRJEB10878: 74/54; g=+0.315; p=0.0139; PRJDB4176: 258/251; g=+0.158; p=0.0227), and the Japanese adenoma contrast was also significant (67/251; g=+0.242; p=0.0123). The pooled raw-read CRC contrast was g=+0.265 (95% CI +0.093 to +0.438; I²=31%), and the whole-genome-only and Asia-only subsets were concordant (Table 10). Among IBD datasets, MetaHIT showed a consistent direction without significance (g=−0.130; p=0.097) and Hall was null (g=+0.084; p=0.373), while HMP2 and Vogtmann were at or below the detection floor (Figure 4A). Pooling the raw-read contrasts by phenotype gave CRC g=+0.265 (k=7), adenoma g=+0.154 (k=3), type 2 diabetes g=−0.160 (k=2), impaired glucose tolerance g=−0.104 (k=2) and IBD g=−0.029 (k=2).

**Table 9. Within-project case–control raw-read whole-genome shotgun archaeal quantification.**

| Project | Disease | Population | n (case/control) | Statistic |
| --- | --- | --- | --- | --- |
| PRJEB10878 | CRC | China | 74 / 54 | g=+0.315; p=0.0139 |
| PRJDB4176 | CRC | Japan | 258 / 251 | g=+0.158; p=0.0227 |
| PRJDB4176 | Adenoma | Japan | 67 / 251 | g=+0.242; p=0.0123 |
| FengQ_2015 | CRC | Austria/China | 46 / 61 | g=+0.660; p=0.001 |
| HanniganGD_2017 | CRC | USA/Canada | 27 / 28 | g=+0.345; p=0.20 |
| WirbelJ_2018 | CRC | Germany | 22 / 60 | g=+0.051; p=0.84 |
| ZellerG_2014 | CRC | France | 53 / 61 | g=+0.042; p=0.82 |
| MetaHIT/PRJEB1220 | IBD | Europe | 82 / 236 | g=−0.130; p=0.097 |
| PRJNA385949 | IBD | USA | 185 / 74 | g=+0.084; p=0.373 |
| PRJNA398089 | IBD | USA | 2197 / 782 | below detection floor |
| PRJEB12449 | CRC | USA | 418 / 416 | unusable (archaea≈0) |
| PRJNA422434 | Type 2 diabetes | China | 121 / 74 | g=−0.053; p=0.35 |

**Table 10. Random-effects summary of the raw-read contrasts by phenotype.**

| Phenotype | Studies (k) | g (95% CI) | I² |
| --- | --- | --- | --- |
| CRC | 7 | +0.265 (+0.093 to +0.438) | 31% |
| Adenoma | 3 | +0.154 (−0.134 to +0.442) | 26% |
| Type 2 diabetes | 2 | −0.160 (−0.433 to +0.113) | 22% |
| Impaired glucose tolerance | 2 | −0.104 (−0.239 to +0.031) | 0% |
| IBD | 2 | −0.029 (−0.239 to +0.180) | 23% |



### 3.14 Independent raw-read replication — 16S amplicon
Within-project 16S results are given in Table 11. A deeply sequenced Asian CRC cohort (PRJEB53891; 20/10; pre-surgery samples) showed a 6.38-fold higher archaeal fraction in CRC than in controls (g=+0.735; p=0.064). A large shallow cohort (PRJNA763023; 564/474) was not significant and was confounded by depth. A deeply sequenced Japanese adenoma cohort (PRJDB16834; 37/66) was null (g=+0.055; p=0.73). Finally, a Japanese CRC cohort (PRJDB11845; 52/51) showed zero detection in both groups owing to bacterial-type primers (Figure 4B–D).

**Table 11. Within-project case–control raw 16S archaeal quantification.**

| Project | Disease | Population | n (case/control) | Result | Statistic |
| --- | --- | --- | --- | --- | --- |
| PRJEB53891 | CRC | Asia | 20 / 10 | 1.13% vs 0.18% (6.38×) | g=+0.735; p=0.064 |
| PRJNA763023 | CRC | China | 564 / 474 | detection 11.0% vs 13.9% | not significant (depth-confounded) |
| PRJDB16834 | Adenoma | Japan | 37 / 66 | 0.0225% vs 0.0209% | g=+0.055; p=0.73 |
| PRJDB11845 | CRC | Japan | 52 / 51 | 0% detection in both groups | primer bias |


### 3.15 Detection-failure annotations in multi-omic and longitudinal data
Among 735 HMP2 metatranscriptomic samples, only 20 (2.7%) carried METHANOGENESIS-PWY transcripts, and these were of low abundance, while the corresponding DNA positivity was 1.0% (Figure 5A); these are non-detection events under the current analytical pipeline and cannot be equated with true absence. In the IBDMDB longitudinal set, mean archaeal abundance was −1.90 in IBD versus −1.74 in controls, and the within-subject temporal slope was close to zero. These findings indicate that functional activity of methanogens is largely un-assessable in current public data.



### 3.16 Mendelian randomisation and power (Supplementary)
With eight instruments (mean F=21), the inverse-variance-weighted estimates were null: CRC OR=1.06 (95% CI 0.97 to 1.17 per one-SD genetically predicted exposure; I²=0%; MR-Egger intercept p=0.16) and IBD OR=1.04 (95% CI 0.95 to 1.13; I²=0%; MR-Egger intercept p=0.33). At the achieved precision, 80% power required OR≥1.14 and power at the observed effect (OR=1.06) was about 0.23, so the null estimate does not exclude small-to-moderate causal effects (Figure 5B). The result is read as "indeterminate", not "non-causal", and it does not bear on the detection-limitation mechanism.


### 3.17 Dataset-level technical limitations
In PRJDB11845, approximately 95% of reads aligned to bacterial 16S and none to archaea. Chinese and Japanese cohorts generally showed detectable archaea whereas the HMP2 and Vogtmann cohorts were largely below the detection floor. In PRJNA763023, the CRC group had a lower median depth (33,724 reads) than the control group (54,137 reads); depth was a strong predictor of detection in this cohort (odds ratio 16.2 per log10 reads; p=2.9×10⁻¹⁰), the case–control detection contrast was not significant before adjustment (odds ratio 0.76; p=0.15) and remained non-significant after adjustment for depth (odds ratio 0.91; p=0.62), and the abundance contrast among detected samples was likewise null before (β=0.141; p=0.17) and after (β=0.122; p=0.24) adjustment. The weak case–control difference in this shallow cohort is therefore attributable to depth, and the cohort does not contribute an independent archaea–disease signal.

---

### 3.18 Total-load adjustment, publication bias and sensitivity
Adjusting for sequencing depth changed the CRC estimate from +0.212 to +0.212 and the IBD estimate from −0.205 to −0.201 (Table 12); the association estimates were essentially unchanged, indicating relative robustness to the depth adjustment applied here. Because no per-sample microbial load measurement was available, a compositional influence of relative abundance cannot be excluded. Egger's test indicated asymmetry (p<0.001) (Figure 6A), whereas trim-and-fill imputed no additional studies (k0=0) for CRC, IBD or any other phenotype (Figure 6B); because no missing studies were imputed, the Egger asymmetry was not interpreted as evidence of publication bias and is more plausibly explained by between-study differences in measurement platform and population (Figure 6C).

**Table 12. Sensitivity of the pooled estimates.**

| Analysis | CRC | IBD |
| --- | --- | --- |
| Unadjusted g | +0.212 | −0.205 |
| Total-load-adjusted g | +0.212 | −0.201 |
| Change | −0.1% | +1.8% |
| Prediction interval | −0.19 to +0.79 | −1.21 to +0.56 |
| Trim-and-fill imputed studies (k0) | 0 | 0 |





### 3.19 Ground-truth validation and minimum detectable abundance
In MBARC-26 the whole-genome archaeal fraction was 11.07% and the standard 16S V3-V4 fraction was 10.03% (about 91% relative recovery), and the whole-genome fraction was stable across depths (10.73% at 25,000 reads to 11.09% at 1,000,000). For M. smithii spiked into a real bacterial background, detection was 100% at every abundance and depth tested and the detected count matched the number spiked in (for example, 501 detected versus 501 expected at 0.1% and 500,000 reads), indicating quantitative recovery down to a single read. Detection is therefore governed by Poisson sampling of the expected number of archaeal reads (abundance x depth) rather than by the aligner; a 95% detection probability corresponds to about three expected reads, i.e. a minimum detectable abundance of about 0.012% at 25,000 reads, 0.003% at 100,000, 0.0006% at 500,000 and 0.0003% at 1,000,000. A dataset is informative for a given archaeon only when abundance x depth exceeds this range.


### 3.20 Detection fragility of published genus–disease associations
The IBD depletion of Akkermansia, one of the most frequently reported IBD-associated taxa, was largely attributable to loss of detection: prevalence was lower in cases in every study (odds ratios 0.16 to 0.43, p<0.01 in three of four), while the abundance contrast among detected samples collapsed (median Hedges g −0.42 on the full scale versus −0.03 among detected samples). The same signature was seen for Barnesiella, Coprobacter, Odoribacter, Oscillibacter and Bilophila: full-scale depletion but near-null abundance among detected samples (several reversing sign). Thus, for these taxa the reported disease association is a detection (prevalence) effect rather than an abundance effect, and reporting relative abundance without separating detection from abundance systematically distorts the association. This is a concrete, reproducible example of a published association that is attenuated (and in several studies reversed) once detection is accounted for.
## 4. Discussion

### 4.1 Principal findings
Three independent evidence lines converge on a single conclusion: the archaeal signal that is reportable from public faecal data is a depth- and pipeline-dependent quantity rather than a fixed biological property, and the commonly reported disease associations are shaped by how well the taxon is detected. (i) In a real, defined mock community the pipeline was accurate and specific (0% false positives; ~100% recovery), so the limiting factor is sampling rather than alignment. (ii) Across 26,731 public stool metagenomes, the odds of detection rose by a factor of 2.07 per log10 increase in reads (p=1.3×10⁻¹⁸); the relationship was significantly non-linear and concave, and the estimate was stable under leave-one-study-out refitting (0.654–0.874), with no detectable disease-group association. (iii) Re-analysis of a real mock established a minimum detectable abundance (MDA) of about three expected reads (≈0.012% at 25,000 reads; ≈0.0003% at 1,000,000), a threshold that scales as ~3/depth. Together these lines convert a qualitative worry — that archaea may be under-detected — into a quantitative criterion that can be applied to a dataset before an association is interpreted.

### 4.2 A detection-versus-abundance framework
Three quantities that are routinely conflated must be separated. The *detection rate* is a prevalence-like property of a sample set; the *assay sensitivity* is the probability of detecting a taxon that is present at a given abundance and depth; and *adequacy* is whether a dataset is informative for a given taxon at all. Because the MDA scales as ~3/depth, adequacy is a joint property of abundance and depth rather than a property of the study label, so the same dataset can be adequate for an organism at 1% and simultaneously blind to an archaeon at 0.01%. Applying this decomposition to 281 genera across 15 case–control studies shows that several frequently reported IBD "depletions" — including *Akkermansia* — are carried by loss of detection (prevalence odds ratios 0.16–0.43; p<0.01 in three of four studies) rather than by reduced abundance among detected samples (full-scale g −0.42 versus among-detected −0.03). A two-part (detection plus conditional-abundance) model is the natural estimator here, because a single zero-inflated relative-abundance table cannot by itself distinguish a biological zero from a sampling zero [13,14]. The same caveat applies to the effective detection threshold set by quality filtering and normalisation [16], and to the compositional constraint that limits relative-abundance data as a proxy for the underlying community [12].

### 4.3 Relation to prior work
Prior archaeal work had already hinted that methanogens track host metabolism and disease [4-7], that breath methane reflects archaeal load [8,9], that archaea shape biofilms and systemic phenotypes [17-20], and that archaeal abundance covaries with obesity, bile-acid and multi-kingdom phenotypes [21-24]. Our contribution is not a new association but a technical audit of how these signals become visible: the same read-level data can support opposite conclusions depending on depth, primer and platform. This reconciles the long-standing heterogeneity of the archaeal literature — a near-null effect in some cohorts and a strong effect in others — with a single sampling mechanism, and it generalises beyond archaea to any taxon near the detection edge.

The methodological ingredients of this audit are themselves long established. Primer choice strongly conditions which taxa are recoverable, because archaeal 16S rRNA genes are poorly matched by bacterial-type primers [10,11]. Count normalisation and rarefaction alter both the sensitivity and the specificity of downstream tests [13,14], quality filtering sets an effective threshold on rare sequences [16], relative-abundance profiles are compositional and carry no information on absolute load [12], and absolute quantification changes the biological interpretation of the same community [15]. What has been missing is not the toolkit but its systematic application to a concrete, clinically salient association, together with an explicit detection threshold against which a dataset can be judged before an association is interpreted.

A second line of prior work — on rumen fermentation under chronic low oxygen — had already reframed methanogenesis as a redox event: methane output in a hypoxic fermenter is the terminal step of a hydrogen economy bounded by the available oxidants, so the observable methane signal is set as much by the reducing environment as by the methanogen community itself [2]. The present study carries that reorientation from a system in which deep sequencing is the norm to one in which public data are typically shallow, and asks the symmetric question: if the environment bounds what a methanogen *can do*, how strongly does sequencing depth bound what we *can see*? The answer — an MDA of about three reads and a depth-dependent detection gradient — is the human-gut counterpart of that redox framing, and it is what makes the reported disease associations an object of methodological, rather than purely biological, uncertainty.

### 4.4 Alternative explanations and falsifiable predictions
At least four explanations other than detection failure could produce a weak or inconsistent archaea–disease association, and they make different predictions. (i) A genuine but small biological effect predicts that depth adjustment should leave the effect size unchanged — which is what we observe for the group contrast (CRC +0.407→+0.408; IBD −0.408→−0.394). (ii) A compositional shift, in which the archaeal fraction changes only because other taxa change, predicts that the functional methanogenic capacity should not move with the taxonomic fraction — yet METHANOGENESIS-PWY rose 3.80-fold in CRC and fell to 0.34-fold in IBD [12]. (iii) A difference in absolute microbial load that normalisation removes [15] predicts that a load-adjusted model would abolish the signal; adjusting for total load changed the estimates by at most 1.8%. (iv) Study- or platform-level technical bias predicts that the effect should drift with depth within the same samples — which the depth-attenuation experiment confirms (China: detection 31%→73% and g +0.190→+0.315 as depth rises from 2.5×10⁴ to 5×10⁵ reads). (v) A mapping-quality artefact predicts that the signal would vanish once ambiguously mapped reads are removed — it does not: MAPQ ≥ 20 retains 95% of archaeal reads and leaves the CRC-to-control ratio unchanged (63.0 versus 62.3). The pattern is therefore most consistent with a real but detection-limited association. The discriminating measurement that would settle the question is specified here as a falsification test: absolute archaeal load by quantitative PCR, with a spike-in standard, on deeply and shallowly sequenced aliquots of the same samples — this should recover a depth-dependent signal if the detection-failure hypothesis is correct, and should not if it is wrong.

### 4.5 Mechanistic interpretation
The direction of the association is coherent with a hydrogen-economy reading of the gut. In CRC, altered mucus and sulfur metabolism in the tumour microenvironment can increase hydrogen availability and reduce competing sulfate reduction, favouring methanogens; in IBD, inflammation raises mucosal oxygen and nitrate, which both disfavours strictly anaerobic methanogens and favours nitrate- and sulfur-respiring competitors [3]. Under this reading the relevant state variables are the hydrogen partial pressure and the luminal redox potential, not abundance per se — and a taxon measured through a relative-abundance lens is a poor proxy for a gas-phase process. That the methane pool is not inert is shown by evidence that a gut methanotroph can lower methane and alter peristalsis and fat metabolism [20]; by the same token, a detection-limited taxonomic signal cannot substitute for a flux measurement.

### 4.6 Implications for practice and clinical translation
Four reporting practices follow directly from the results. (i) Report the analysis depth and the effective (post-QC) depth separately. (ii) State the positivity rule and its threshold sensitivity — in our data, detection fell from 41% at ≥1 read to 15% at ≥5 reads at the same depth. (iii) For low-prevalence taxa, report detection and abundance separately in a two-part model. (iv) Report an abundance×depth adequacy check against a data-derived MDA. These are cheap, reproducible steps that convert "absence of evidence" into "evidence about absence". For clinical translation the same reasoning applies to breath testing and to IMO: breath methane and sequence-based abundance are obtained at different depths and with different detection floors [8,9,25,26], so a negative breath test and an undetected archaeon in a shallow metagenome may reflect the same sampling limitation rather than true absence [27]. Reporting detection separately from abundance, and stating depth and the positivity rule, would make both the research and the clinical signal comparable across platforms.

### 4.7 Limitations
The ground-truth mock contained haloarchaea rather than gut methanogens, and the MDA spike-in used in-silico reads over a real bacterial background; the MDA is therefore an upper bound on sensitivity rather than a stool-specific truth, and it will be optimistically small for real DNA, which is subject to extraction, PCR and library biases. The quantitative line cannot separate regional from study-level technical effects, so all regional findings are exploratory. Mendelian randomisation was power-limited (≈0.23 at the observed effect) and cannot validate the detection mechanism. No absolute load was measured, so a compositional influence cannot be formally excluded. Finally, the raw-read replication overlaps the quantitative line and provides cross-pipeline consistency rather than external validation.

### 4.8 Conclusions and outlook
"Not detected" is not "absent". Sequencing-depth-dependent detection limits systematically shape which gut archaea (and other low-abundance taxa) become visible, and can reverse the sign of reported microbiome–disease associations. Quantifying a minimum detectable abundance and reporting detection separately from abundance would make the next generation of microbiome associations reproducible rather than an artefact of how deeply, and with which primers, a sample happened to be sequenced.

Four questions remain open and are stated here as explicit gaps. First, what is the true absolute abundance of gut archaea across populations, and does it track the reported disease associations once measured by quantitative PCR with a standard on deeply sequenced material? Second, does the depth-dependent detection gradient observed here hold for other primer systems, including archaea-compatible 16S assays and long-read platforms? Third, at what sequencing depth do reported archaea–disease associations become stable across cohorts, and is that depth attainable at population scale? Fourth, can a data-derived MDA be coupled to a prospective power calculation, so that dataset adequacy is specified before an association is tested rather than interpreted after the fact?

## References

1. Duller et al. Targeted isolation of Methanobrevibacter strains from fecal samples expands the cultivated human archaeome. Nature Communications. 2024. doi:10.1038/s41467-024-52037-7
2. Kumpitsch et al. Reduced B12 uptake and increased gastrointestinal formate are associated with archaeome-mediated breath methane emission in humans. Microbiome. 2021. doi:10.1186/s40168-021-01130-w
3. Villanueva-Millan et al. Methanogens and Hydrogen Sulfide Producing Bacteria Guide Distinct Gut Microbe Profiles and Irritable Bowel Syndrome Subtypes. American Journal of Gastroenterology. 2022. doi:10.14309/ajg.0000000000001997
4. Mohammadzadeh et al. Cross-domain metabolic interactions link Methanobrevibacter smithii to colorectal cancer microbial ecosystems. Nature Communications. 2026. doi:10.1038/s41467-026-69711-7
5. Li et al. Multi-Cohort Analysis Reveals Altered Archaea in Colorectal Cancer Fecal Samples Across Populations. Gastroenterology. 2025. doi:10.1053/j.gastro.2024.10.023
6. Wang et al. Methanogen Levels Are Significantly Associated with Fecal Microbiota Composition and Alpha Diversity in Healthy Adults and Irritable Bowel Syndrome Patients. Microbiology Spectrum. 2022. doi:10.1128/spectrum.01653-22
7. Woh et al. Reevaluation of the gastrointestinal methanogenic archaeome in multiple sclerosis and its association with treatment. Microbiology Spectrum. 2025. doi:10.1128/spectrum.02183-24
8. Pimentel et al. Real-world Study of Three-gas Breath Testing Nationwide and the Association With Symptoms. Journal of Clinical Gastroenterology. 2026. doi:10.1097/MCG.0000000000002326
9. Rezaie et al. How to Test and Treat Small Intestinal Bacterial Overgrowth: an Evidence-Based Approach. Current Gastroenterology Reports. 2016. doi:10.1007/s11894-015-0482-9
10. Takahashi et al. Development of a prokaryotic universal primer for simultaneous analysis of Bacteria and Archaea using next-generation sequencing. PLoS ONE. 2014. doi:10.1371/journal.pone.0105592
11. Parada et al. Every base matters: assessing small subunit rRNA primers for marine microbiomes with mock communities, time series and global field samples. Environmental Microbiology. 2015. doi:10.1111/1462-2920.13023
12. Gloor et al. Microbiome datasets are compositional: and this is not optional. Frontiers in Microbiology. 2017. doi:10.3389/fmicb.2017.02224
13. McMurdie et al. Waste not, want not: why rarefying microbiome data is inadmissible. PLoS Computational Biology. 2014. doi:10.1371/journal.pcbi.1003531
14. Weiss et al. Normalization and microbial differential abundance strategies depend upon data characteristics. Microbiome. 2017. doi:10.1186/s40168-017-0237-y
15. Vandeputte et al. Quantitative microbiome profiling links gut community variation to microbial load. Nature. 2017. doi:10.1038/nature24460
16. Bokulich et al. Quality-filtering vastly improves diversity estimates from Illumina amplicon sequencing. Nature Methods. 2013. doi:10.1038/nmeth.2276
17. Orgler et al. Archaea influence composition of endoscopically visible ileocolonic biofilms. Gut Microbes. 2024. doi:10.1080/19490976.2024.2359500
18. Mirza et al. Metagenomic Analysis of the Pediatric-Onset Multiple Sclerosis Gut Microbiome. Neurology. 2022. doi:10.1212/WNL.0000000000013245
19. Fumagalli et al. Archaea methanogens are associated with cognitive performance through the shaping of gut microbiota, butyrate and histidine metabolism. Gut Microbes. 2025. doi:10.1080/19490976.2025.2455506
20. Zhao et al. The gut methanotroph Methylocystis intestini modulates intestinal peristalsis and fat metabolism via reducing methane levels. Nature Communications. 2025. doi:10.1038/s41467-025-66596-w
21. Yamamura et al. Increased fecal glycocholic acid levels correlate with obesity in conjunction with the depletion of archaea: The Dosanco Health Study. The Journal of Nutritional Biochemistry. 2025. doi:10.1016/j.jnutbio.2025.109846
22. Gallardo-Nuell et al. Ecological restructuring of the nonbacterial fecal microbiome in obesity across human cohorts. Gut Microbes. 2026. doi:10.1080/19490976.2026.2701446
23. Hu et al. Integrative metagenomic analysis reveals distinct gut microbial signatures related to obesity. BMC Microbiology. 2024. doi:10.1186/s12866-024-03278-5
24. Chen et al. Multi-kingdom gut microbiota dysbiosis is associated with the development of pulmonary arterial hypertension. eBioMedicine. 2025. doi:10.1016/j.ebiom.2025.105686
25. Talamantes et al. Intestinal Methanogen Overgrowth (IMO) Is Associated with Delayed Small Bowel and Colonic Transit Time (TT) on the Wireless Motility Capsule (WMC). Digestive Diseases and Sciences. 2024. doi:10.1007/s10620-024-08563-x
26. Laserna Mendieta et al. Detection capacity of small intestine bacterial or methanogen overgrowth by lactose and fructose breath testing in the adult population. Advances in Laboratory Medicine. 2024. doi:10.1515/almed-2024-0115
27. Wang et al. Intestinal methanogen overgrowth and its impact on gastrointestinal disorders in children: a retrospective study. BMC Gastroenterology. 2025. doi:10.1186/s12876-025-04406-9

## 5. Back matter

**Search strategy.** PubMed/Embase/Web of Science were searched with combinations of archaea/methanogen terms and human gut terms; the full Boolean strings, databases, and the search cutoff date are given in the Supplementary Material.

**Reproducibility.** To allow independent reproduction of the main figures and core results, the following are provided in the Supplementary Material: the sample list with study and accession identifiers; the cohort-overlap table (Supplementary Table S1); reference-database versions (curatedMetagenomicData release; RefSeq Targeted Loci release for the 16S reference; the archaeal genome set); software versions (bowtie2, samtools, MetaPhlAn, Python/statsmodels); random seeds for subsampling; and the complete analysis scripts. The PRISMA 2020 checklist is provided. No prospective registration was performed (only public secondary data were used).

**Data availability.** The quantitative line uses curatedMetagenomicData; raw-read data derive from public accessions PRJEB10878, PRJDB4176, PRJEB53891, PRJNA763023, PRJEB1220, PRJNA385949, PRJNA398089, PRJEB12449, PRJDB16834, PRJDB11845 and PRJNA422434. Analytical scripts, input manifests and intermediate result tables are openly archived at Zenodo (https://doi.org/10.5281/zenodo.23397860; release v1.0.0).

**Funding.** To be completed with grant names and numbers.

**Author contributions (CRediT).** Conceptualization; Methodology; Investigation; Formal analysis; Data curation; Validation; Writing – original draft; Writing – review & editing (all authors). To be completed.

**Conflicts of interest.** None declared.

**Ethics.** Not applicable (public secondary data; no primary participants).

**Declaration of generative AI use.** Per journal policy.

