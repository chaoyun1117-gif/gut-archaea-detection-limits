# Cover Letter / 投稿信

**Date / 日期:** [填：YYYY-MM-DD]

**To / 收件:** The Editor-in-Chief, *[目标期刊 / Target journal]*

**Re: Submission of an original research article / 投稿：原创研究论文**

---

## English

Dear Editor,

We are pleased to submit our original research article entitled **"Sequencing-depth-dependent detection limits of gut methanogenic archaea and detection-driven distortion of microbiome–disease associations: a depth-aware re-appraisal of 28,445 metagenomes"** for consideration in *[target journal]*.

**The problem.** Gut methanogenic archaea (*Methanobrevibacter* and relatives) are numerically rare but metabolically pivotal. Their reported associations with disease — elevated in colorectal cancer (CRC), depleted in inflammatory bowel disease (IBD) — are widely cited, yet these organisms sit close to the detection floor of both 16S amplicon and shotgun pipelines. Whether the reported signals reflect biology, or the technical conditions under which the data were generated, has not been systematically separated.

**What we did.** We re-appraised 28,445 metagenomes (110 studies) with an explicitly *depth-aware* framework, and anchored it with controlled ground-truth and detection-limit experiments.

**What we found.**
- Archaeal **detection** is dominated by technical factors (library depth, platform, extraction), not disease group; detection scaled with depth (study-level OR ≈ 2.07 per log-read, p ≈ 1.3×10⁻¹⁸) with no disease-group association.
- In a simulated-spike ground-truth experiment, the **minimum detectable abundance (MDA) scaled at ≈ 3 / sequencing depth** — a generalisable detection-limit benchmark.
- A concrete **flip case**: the widely reported *Akkermansia* "depletion" in IBD is reproduced as a prevalence/detection effect — naïve pooled effect negative, but among-detected samples essentially null — i.e. a detection artifact rather than a true abundance difference.
- Re-analysing independent raw reads (WGS and 16S) reproduced the detection-limited picture; the archaeal−CRC association survives depth adjustment, whereas the IBD association does not (its prediction interval crosses zero).

**Why it matters.** The work provides (i) a quantitative detection-limit standard, (ii) a depth-aware re-appraisal protocol, and (iii) a demonstration that at least one headline microbiome–disease association is detection-driven. We believe this is directly relevant to the reproducibility of microbiome studies, the central remit of *[target journal]*.

**Declarations.** All analyses use public secondary data; no new human participants were enrolled, so ethics approval is not applicable. The manuscript is original, is not under consideration elsewhere, and all authors approve submission. The authors declare no competing interests. Data sources, accessions, software versions and scripts required for reproduction are listed in the manuscript and its Supplementary Material.

Thank you for your consideration.

Yours sincerely,

**Chaoyun Yang**
Xichang University
Email: chaoyuny@yeah.net
ORCID: 0000-0001-6190-7958

---

## 中文

尊敬的编辑：

我们谨向 *[目标期刊]* 投递原创研究论文 **《肠道产甲烷古菌的测序深度依赖检出限制，及检测驱动的微生物组–疾病关联偏倚：基于 28,445 份宏基因组的深度感知再评估》**，敬请审阅。

**问题背景。** 肠道产甲烷古菌（*Methanobrevibacter* 及其近缘）数量稀少但代谢关键。其与疾病的关联——结直肠癌（CRC）中升高、炎症性肠病（IBD）中降低——被广泛引用；但这类微生物同时贴近 16S 扩增子与鸟枪法管线的检出下限。已报道的信号究竟是生物学差异，还是数据产生时的技术条件所致，此前未被系统分离。

**我们做了什么。** 我们以显式"深度感知"框架重评估了 **28,445 份宏基因组（110 项研究）**，并用可控的**真值验证与检出限实验**加以锚定。

**主要发现。**
- 古菌**检出**由技术因素（文库深度、测序平台、提取方法）主导，而非疾病分组；检出率随深度上升（研究级 OR ≈ 2.07 / 每 log 读数，p ≈ 1.3×10⁻¹⁸），未见疾病组关联。
- 在模拟掺入的真值实验中，**最低可检出丰度（MDA）≈ 3 / 测序深度**——形成一个可推广的检出限基准。
- 一个具体的**翻案案例**：被广泛报道的 IBD 中 *Akkermansia* "耗竭"，被复现为**患病率/检出效应**——朴素合并效应为负，而"仅检测到样本内"的效应基本为零——即检测伪象，而非真实丰度差异。
- 对独立原始读数（WGS 与 16S）的再分析复现了"检出受限"图景；古菌–CRC 关联在深度校正后仍稳健，而 IBD 关联不稳健（其预测区间跨零）。

**意义。** 本工作提供 (i) 一个定量的检出限标准，(ii) 一套深度感知的再评估流程，(iii) 至少一个头部微生物组–疾病关联被证明是"检测驱动"的例证。我们相信这对微生物组研究的可复现性——亦即 *[目标期刊]* 的核心关切——具有直接价值。

**声明。** 全部分析均使用公开二手数据，未招募新的受试者，故不适用伦理审批。稿件为原创、未一稿多投，全体作者同意投稿，无利益冲突。复现所需的数据库来源、登录号、软件版本与脚本均已列于正文及补充材料。

感谢审阅。

此致

**杨朝云 (Chaoyun Yang)**
西昌学院 (Xichang University)
邮箱：chaoyuny@yeah.net
ORCID：0000-0001-6190-7958

---

### 使用提示
- 发送前把 `[目标期刊]`、日期、以及正文 back matter 中的 Funding / CRediT / 通讯地址占位补全。
- 如目标刊要求推荐/回避审稿人（suggested/excluded reviewers），可另附一页。
