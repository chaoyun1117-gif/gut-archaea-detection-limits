# -*- coding: utf-8 -*-
"""Spec-compliant figure style for the manuscript.
Rules (from 论文写作规范 §4): white bg, flat fills, unified line widths,
width = 170 mm, fonts 7-8 pt, 1:1 (image physical width == display width),
600 dpi, NO bbox_inches='tight' (use fixed subplots_adjust / manual layout)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

WMM = 170.0
WIN = WMM / 25.4            # 6.6929 in  → 1:1 at 170 mm display width
DPI = 600
FS  = 7.5                    # 小五-ish, within the 7-8 pt requested

def apply(fs=FS, dpi=DPI):
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": fs,
        "axes.titlesize": fs, "axes.labelsize": fs,
        "xtick.labelsize": fs, "ytick.labelsize": fs, "legend.fontsize": fs,
        "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "figure.dpi": dpi, "savefig.dpi": dpi,
        "figure.facecolor": "white", "savefig.facecolor": "white",
    })

def fig(width_mm=WMM, height_mm=60):
    apply()
    return plt.figure(figsize=(width_mm/25.4, height_mm/25.4))

def save(fig_, path):
    # fixed margins (no tight) so the saved width stays exactly 170 mm
    fig_.savefig(path, dpi=DPI, facecolor="white")
    print("saved", path)
