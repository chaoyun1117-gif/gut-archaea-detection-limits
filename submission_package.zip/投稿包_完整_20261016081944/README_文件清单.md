# 完整投稿包（图文分离 · 拼图版 · 字号统一 9pt）
- 正文/Manuscript_EN.docx —— 正文（零图片；图以 (Figure N[面板]) 按首现顺序引用）
- 正文/Figure_Legends_EN.md —— 图题注（Figure 1..6，含 A/B/C/D）
- 正文/Manuscript_CN.docx · 图题注_CN.md —— 中文对应件
- 图片/Figure 1..6.png —— 拼图（600 dpi 无损；170 mm；**图内字号统一 小五 9pt，1:1**）
- 图片/Figure 1..6.pdf —— 矢量版（便于手动美化）
- 脚本/ —— 出图脚本；数据表/ · 补充材料/ · 投稿信_CoverLetter.md
